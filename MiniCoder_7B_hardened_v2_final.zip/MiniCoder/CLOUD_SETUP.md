# MiniCoder Cloud V2 설정 안내

## 구현 경계 한눈에 보기

- **Kaggle:** Kaggle 공식 CLI의 `kernels push/status/output`을 호출하는 실행 클라이언트와 보호된 대시보드 API가 있습니다. 커널 실행은 사용자 계정 쿼터를 쓸 수 있으므로 별도 확인 없이는 제출하지 않습니다. 계정 토큰은 사용자가 Kaggle CLI에 미리 안전하게 설정해야 하며 이 프로젝트는 토큰 내용을 읽거나 저장하지 않습니다.
- **Google Colab:** 실제 GPU 확인, 합성/사용자가 선택한 데이터 경로, Drive 체크포인트, 무결성 확인 재개, export가 들어간 실행 노트북이 있습니다. 공식 Colab Runtime/MCP API는 조사했으나 이 릴리스에는 외부 컨트롤러용 OAuth client를 통합하지 않았습니다. 따라서 사용자가 Colab에서 노트북을 여는 방식만 제공됩니다.
- **Lightning/Modal:** provider 설정·inspection이 있으며 외부 SDK/작업 API는 계정 자격과 비용 게이트가 필요합니다. Lightning 작업 제출기는 구현하지 않았습니다. Modal은 선택적 App이지만, 실제 호출은 사용자가 현재 가격을 확인하고 명시적 승인, 양수 요금률과 USD 예산을 직접 지정해야 합니다.
- **ZeroGPU:** 짧은 앱 함수/추론 데모만을 대상으로 하며 장시간 학습 scheduler가 아닙니다.
- **Local:** 현재 Python process에서 GPU/RAM/disk를 측정하고, 작은 local process만 실행합니다. Provider간 GPU 메모리 합산은 하지 않습니다.

공식 API의 상세 비교와 출처는 [`docs/CLOUD_V2_PROVIDER_API_RESEARCH.md`](docs/CLOUD_V2_PROVIDER_API_RESEARCH.md), 구현 상태는 [`PROVIDER_STATUS.md`](PROVIDER_STATUS.md)를 참고하세요. 계정별 자격·GPU 적격성·quota·잔액은 조회하거나 추정하지 않습니다.

## Kaggle 공식 CLI 제출

1. 본인 Kaggle 계정에서 API token을 발급하고 Kaggle 공식 CLI 인증을 로컬의 안전한 사용자 설정/환경에 구성합니다. 파일 내용을 notebook, dashboard, Git에 복사하지 마세요.
2. Kaggle에서 실행할 노트북 폴더를 만듭니다. `kernel-metadata.json`의 `id`, `title`, `code_file`, `language`, `kernel_type`, `is_private`와 실제 사용하려는 `dataset_sources`, `enable_gpu`, `enable_internet`를 정확히 기입합니다. 가속기/인터넷은 필요한 경우에만 요청하세요.
3. 준비한 metadata JSON으로 metadata를 검사·생성합니다.

```bash
python -m providers.kaggle_jobs prepare \
  --kernel-dir kaggle_submission \
  --metadata-json kaggle_submission_config.json
```

4. 제출하면 새 Kaggle kernel version 실행이 시작되며 GPU 요청은 계정 쿼터를 사용할 수 있습니다. 현재 계정의 잔여 시간, 가속기 적격성, 예약 가능성은 Kaggle에서 확인한 후에만 다음 명령의 확인 flag를 붙입니다.

```bash
python -m providers.kaggle_jobs submit \
  --kernel-dir kaggle_submission \
  --confirm-submit
```

5. 상태 확인 및 완료 output 다운로드:

```bash
python -m providers.kaggle_jobs status --kernel-id OWNER/KERNEL
python -m providers.kaggle_jobs output --kernel-id OWNER/KERNEL --destination runs/kaggle_output
```

Kaggle CLI가 설치되어 있지 않으면 Kaggle의 공식 설치 안내를 보고 본인 환경에 설치하세요. `submit`은 공식 CLI 호출만 사용하고 임의 REST endpoint, 브라우저 자동화, 비밀번호/token 출력은 하지 않습니다. 로컬 테스트에서 외부 요청은 mock으로 대체되며 실제 계정 실행이 검증되었다는 뜻이 아닙니다. 주간 쿼터 및 session policy는 시점·계정에 따라 달라질 수 있습니다.

Dashboard의 Kaggle 패널도 위 기능에 대응하는 protected endpoint를 제공하며, dashboard가 실행되는 호스트에 Kaggle CLI 및 사용자 자격 설정이 필요합니다. Dashboard 원격 제어는 기본 loopback only이고, 원격으로 열려면 `MINICODER_DASHBOARD_TOKEN`과 HTTPS reverse proxy를 준비하세요.

## Google Colab Tiny 학습

1. Google Colab에서 GPU runtime을 **사용자가 직접 선택**합니다. GPU 제공은 보장되지 않습니다.
2. [`notebooks/minicoder_colab.ipynb`](notebooks/minicoder_colab.ipynb)을 열고 Google Drive mount를 승인합니다.
3. 프로젝트 ZIP을 업로드하고 실행합니다. 기본 데이터는 합성 smoke data이며, 자신의 공개/보유 데이터를 쓰려면 먼저 실제 라이선스·출처를 확인하고 notebook 설정을 검토합니다.
4. 이 노트북은 10M Tiny 구조의 짧은 fit/eval, Drive checkpoint, sha256 검증, 재개, model-only export 흐름을 수행합니다. 다른 Colab 세션에서 복구하려면 같은 Drive 폴더에 접근하고 노트북을 다시 실행해야 합니다.

드라이브 mount 인증 및 Colab GPU 할당은 실제 계정에서 확인해야 합니다. 이 project는 일반 Colab official runtime REST/MCP API를 통해 외부에서 새 런타임을 생성하지 않습니다. API 인증과 OAuth를 추가로 구현하기 전에는 API 조사와 현재 notebook 실행 흐름을 구분하세요.

## 데이터 및 영속 저장

로컬/사용자 제공 데이터는 `DatasetRegistry`에 검토한 라이선스 identifier와 출처를 등록합니다. 공개 Hugging Face dataset streaming은 선택 의존성 `requirements-public.txt`와 `dataset.public.load_public_hf_dataset`을 사용합니다. 호출자는 공식 dataset card에서 license를 확인하고 직접 값으로 넣어야 합니다. Loader는 license를 자동 검증하지 않으며, unknown license를 허용하지 않고, remote Python dataset code를 실행하지 않습니다.

Colab은 Drive, Kaggle은 저장된 Notebook output/다음 실행에 연결한 Dataset에서 checkpoint를 회수합니다. 로컬 디렉터리 복구는 SHA-256과 sidecar를 확인하는 `training.recovery.transfer_checkpoint`를 사용합니다. 서로 다른 계정/프로바이더 간 파일 이동은 해당 사용자 인증된 mount 또는 공급자 CLI를 통해 사용자가 시작해야 합니다. 저장소 접근·전송은 실제 외부 계정에서 검증하지 않았습니다.

## 유료 작업

무료 경로가 기본입니다. Modal 실행은 사용자 명시 승인, 현 가격을 확인한 시간당 GPU 요금률 및 최대 USD GPU-compute 추정 예산을 요구합니다. 학습 중 예산에 근접하면 다음 update 이전에 중단하고 checkpoint를 저장합니다. 추정기는 GPU rate × local training elapsed time뿐이며 container startup, CPU/RAM, storage, network, taxes, provider billing granularity를 포함하지 않습니다. **이는 공급자의 강제 billing cap이 아니므로 Dashboard/Modal이 청구액을 보장하지 않습니다.** 공급자 billing dashboard에서 추가 제한을 설정해야 합니다.

Kaggle GPU 제출은 금전 청구가 없다고 가정하지 않더라도 무료 GPU 쿼터를 쓸 수 있으므로 explicit submit confirmation을 요구합니다.

## 7B 모델 전 주의

`python -m training.plan --target auto`는 현재 process의 실제 free VRAM 또는 system RAM, manifest token count를 바탕으로 휴리스틱 구성을 출력하며 학습을 시작하지 않습니다. `--target 7b`에 더 작은 preset이 선택되면 결과는 반드시 사용자 확인이 필요하다고 표시됩니다. 추정 VRAM은 실제 probe가 아니며 7B 시작의 적합성을 보증하지 않습니다. 실제 GPU에서 auto batch probe, 연속 학습, checkpoint restore/export를 통과하기 전에는 7B 학습을 시작하지 마세요.
