"""Local-only registry for inspecting configured provider adapters."""
from __future__ import annotations

from typing import Dict, Iterable, Optional

from providers.base import BaseProvider
from providers.colab import ColabProvider
from providers.detector import detect_environment
from providers.huggingface_zerogpu import HuggingFaceZeroGPUProvider
from providers.kaggle import KaggleProvider
from providers.lightning import LightningProvider
from providers.local import LocalProvider
from providers.modal import ModalProvider


class ProviderRegistry:
    """Collect process-local signals; never authenticates or starts remote work."""

    def __init__(self, providers: Optional[Iterable[BaseProvider]] = None):
        self._providers = list(providers) if providers is not None else [
            LocalProvider(), ColabProvider(), KaggleProvider(), LightningProvider(),
            HuggingFaceZeroGPUProvider(), ModalProvider(),
        ]

    def inspect_all(self) -> Dict:
        reports = {}
        for adapter in self._providers:
            try:
                reports[adapter.provider_name] = adapter.setup_environment()
            except Exception as exc:
                # Expose only exception type, not paths, tokens, or environment values.
                reports[adapter.provider_name] = {
                    "provider": adapter.provider_name,
                    "runtime_detected": False,
                    "inspection_error": type(exc).__name__,
                    "capabilities": {"submit_cloud_job": False, "inspect_cloud_credits_or_quota": False},
                }
        current = detect_environment()
        current_key = {"huggingface_space": "huggingface_zerogpu"}.get(current.provider, current.provider)
        # A hardware fact belongs only to the provider process that is actually
        # executing here. Never copy the current machine's GPU into another row.
        for name, report in reports.items():
            if not isinstance(report, dict):
                continue
            observed = name == current_key and bool(report.get("runtime_detected", True))
            report["runtime_resources"] = {
                "observation_scope": "current_process" if observed else "not_observed_in_this_process",
                "gpu_name": current.gpu_name if observed else None,
                "gpu_available": current.gpu_available if observed else None,
                "vram_total_bytes": current.vram_total_bytes if observed else None,
                "vram_free_bytes": current.vram_free_bytes if observed else None,
                "system_ram_total_bytes": current.system_ram_total_bytes if observed else None,
                "system_ram_available_bytes": current.system_ram_available_bytes if observed else None,
                "torch_version": current.torch_version if observed else None,
                "cuda_runtime": current.cuda_runtime if observed else None,
                "storage_path": current.storage_path if observed else None,
                "storage_free_bytes": current.storage_free_bytes if observed else None,
                "training_process_possible": current.local_training_process_possible if observed else None,
                "session_limit_seconds": None,
                "expected_duration_seconds": None,
                "quota_visibility": "not_available_locally",
                "note": ("Observed in this Python process; provider session/quota is not queried."
                         if observed else "Hardware and duration are unknown because this provider is not executing here."),
            }
        return {
            "current_process": current.to_dict(),
            "remote_actions_performed": False,
            "provider_reports": reports,
        }

    def get(self, provider_name: str) -> BaseProvider:
        name = provider_name.lower()
        for adapter in self._providers:
            if adapter.provider_name.lower() == name:
                return adapter
        raise KeyError(f"unknown provider {provider_name!r}; available: {sorted(p.provider_name for p in self._providers)}")
