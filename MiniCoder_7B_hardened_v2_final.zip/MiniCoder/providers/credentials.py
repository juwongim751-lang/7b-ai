"""Credential presence checks that never return or print secret values."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Mapping, Optional


_PROVIDER_ENV_KEYS = {
    "kaggle": ("KAGGLE_API_TOKEN", "KAGGLE_USERNAME", "KAGGLE_KEY"),
    "huggingface": ("HF_TOKEN", "HUGGINGFACE_HUB_TOKEN"),
    "modal": ("MODAL_TOKEN_ID", "MODAL_TOKEN_SECRET"),
    "lightning": ("LIGHTNING_CLOUD_API_KEY",),
}
_PROVIDER_FILES = {
    "kaggle": (Path.home() / ".kaggle" / "kaggle.json",),
}


def credential_status(provider: str, environ: Optional[Mapping[str, str]] = None) -> dict:
    """Return only configured key names and booleans; never read secret files."""
    env = os.environ if environ is None else environ
    name = provider.lower()
    keys = _PROVIDER_ENV_KEYS.get(name, ())
    env_present = [key for key in keys if bool(env.get(key))]
    files = _PROVIDER_FILES.get(name, ())
    file_present = [str(path) for path in files if path.is_file()]
    return {"provider": name, "configured": bool(env_present or file_present),
            "environment_keys_present": env_present, "credential_file_present": bool(file_present),
            "credential_files": file_present, "secret_values_exposed": False}
