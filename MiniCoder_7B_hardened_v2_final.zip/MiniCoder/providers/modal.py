"""Inspection-only adapter for local Modal SDK/runtime indicators."""
from collections.abc import Mapping
import importlib
import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
from typing import Any
from providers.base import BaseProvider
_UNSET = object()
class ModalProvider(BaseProvider):
    """Inspect local Modal indicators and resources without account or job access."""
    def __init__(
        self,
        env: Mapping[str, str] | None = None,
        working_path: str | os.PathLike[str] | None = None,
        credential_file_path: str | os.PathLike[str] | None = "~/.modal.toml",
        sdk_available: bool | None = None,
        torch_module: Any = _UNSET,
        nvidia_smi_path: str | None | object = _UNSET,
    ):
        super().__init__("modal")
        self._env = os.environ if env is None else env
        self.working_path = Path(working_path) if working_path is not None else Path.cwd()
        self.credential_file_path = (
            Path(credential_file_path).expanduser() if credential_file_path is not None else None
        )
        self._sdk_available_override = sdk_available
        self._torch_module = torch_module
        self._nvidia_smi_path = nvidia_smi_path
    @staticmethod
    def _is_set(env: Mapping[str, str], key: str) -> bool:
        value = env.get(key)
        return value is not None and bool(str(value).strip())
    def _is_remote_flag_set(self) -> bool:
        value = self._env.get("MODAL_IS_REMOTE")
        if value is None:
            return False
        return str(value).strip().lower() in {"1", "true", "yes", "on"}
    def detect_runtime(self) -> dict[str, Any]:
        """Report Modal environment marker presence without returning their values."""
        indicators = {
            "task_id_environment_variable": self._is_set(self._env, "MODAL_TASK_ID"),
            "is_remote_environment_flag": self._is_remote_flag_set(),
        }
        return {"detected": any(indicators.values()), "indicators": indicators}
    def _sdk_available(self) -> bool:
        if self._sdk_available_override is not None:
            return bool(self._sdk_available_override)
        try:
            return importlib.util.find_spec("modal") is not None
        except (ImportError, ValueError, AttributeError):
            return False
    def _get_torch(self) -> Any | None:
        if self._torch_module is not _UNSET:
            return self._torch_module
        try:
            return importlib.import_module("torch")
        except Exception:
            # Optional or incomplete torch installations should not break inspection.
            return None
    def _inspect_torch(self) -> dict[str, Any]:
        torch = self._get_torch()
        if torch is None:
            return {"available": False, "cuda_available": None, "device_count": None, "devices": []}
        result: dict[str, Any] = {
            "available": True,
            "cuda_available": False,
            "device_count": 0,
            "devices": [],
        }
        try:
            cuda = torch.cuda
            result["cuda_available"] = bool(cuda.is_available())
            if result["cuda_available"]:
                count = int(cuda.device_count())
                result["device_count"] = count
                for index in range(count):
                    try:
                        name = str(cuda.get_device_name(index))
                    except Exception:
                        name = None
                    result["devices"].append({"index": index, "name": name})
        except Exception:
            result["cuda_available"] = None
            result["device_count"] = None
            result["devices"] = []
            result["inspection_error"] = "torch_cuda_inspection_failed"
        return result
    def _find_nvidia_smi(self) -> str | None:
        if self._nvidia_smi_path is not _UNSET:
            return self._nvidia_smi_path
        return shutil.which("nvidia-smi")
    def _inspect_nvidia_smi(self) -> dict[str, Any]:
        executable = self._find_nvidia_smi()
        if not executable:
            return {"available": False, "devices": []}
        query = [
            str(executable),
            "--query-gpu=name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ]
        try:
            completed = subprocess.run(
                query,
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            return {"available": True, "query_succeeded": False, "devices": []}
        if completed.returncode != 0:
            return {"available": True, "query_succeeded": False, "devices": []}
        devices = []
        for line in completed.stdout.splitlines():
            fields = [part.strip() for part in line.split(",", 2)]
            if len(fields) == 3:
                name, total, free = fields
                devices.append({"name": name, "memory_total_mib": total, "memory_free_mib": free})
        return {"available": True, "query_succeeded": True, "devices": devices}
    def _credential_presence(self) -> dict[str, bool]:
        """Report credential-source presence only; do not read or validate secrets."""
        token_id = self._is_set(self._env, "MODAL_TOKEN_ID")
        token_secret = self._is_set(self._env, "MODAL_TOKEN_SECRET")
        config_file = False
        if self.credential_file_path is not None:
            try:
                config_file = self.credential_file_path.is_file()
            except OSError:
                config_file = False
        return {
            "token_id_environment_variable_present": token_id,
            "token_secret_environment_variable_present": token_secret,
            "environment_credentials_present": token_id and token_secret,
            "credential_file_present": config_file,
        }
    def inspect_runtime(self) -> dict[str, Any]:
        """Inspect local indicators, SDK discoverability, paths, credentials, and GPU."""
        detection = self.detect_runtime()
        storage_path = self.get_storage_path()
        working_exists = self.working_path.is_dir()
        return {
            "provider": self.provider_name,
            "runtime_detected": detection["detected"],
            "runtime_scope": "modal_remote" if detection["detected"] else "local_process",
            "indicators": detection["indicators"],
            "sdk": {"available_locally": self._sdk_available()},
            "paths": {
                "working": {"path": str(self.working_path), "exists": working_exists},
                "output": {"path": storage_path, "exists": Path(storage_path).is_dir()},
                "checkpoint_storage": storage_path,
            },
            "credentials": self._credential_presence(),
            "gpu": {"torch": self._inspect_torch(), "nvidia_smi": self._inspect_nvidia_smi()},
            "capabilities": {
                "inspect_local_runtime": "supported",
                "inspect_local_gpu": "supported",
                "inspect_local_modal_sdk": "supported",
                "write_local_working_directory": working_exists and os.access(self.working_path, os.W_OK),
                "generate_local_worker_command": "unsupported",
                "execute_worker_command": "unsupported",
                "submit_cloud_job": "unsupported",
                "access_remote_modal_account": "unsupported",
                "inspect_cloud_credits_or_quota": "unsupported",
                "persistent_storage_verified": False,
            },
        }
    def setup_environment(self):
        """Inspect only; do not install packages, authenticate, or mutate the environment."""
        return self.inspect_runtime()
    def get_storage_path(self) -> str:
        """Return a proposed local output path without creating it or claiming persistence."""
        return str(self.working_path / "minicoder_output")
    def run_worker_command(self, rank, world_size, master_addr, master_port):
        """Reject worker generation until a safe, explicit Modal job entrypoint exists."""
        raise NotImplementedError(
            "Modal job submission and worker command generation are unsupported; no job entrypoint is implemented."
        )
