"""Explicit Kaggle CLI job client (official CLI; no private REST endpoints).

The methods submit only after explicit confirmation because a GPU kernel run
consumes account quota. Credentials must be provided by the user's secure CLI
configuration/environment and are never printed by this module.
"""
from __future__ import annotations

import json
import argparse
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Mapping


class KaggleJobError(RuntimeError):
    pass


class KaggleKernelClient:
    def __init__(self, executable=None, env: Mapping[str, str] | None = None,
                 timeout_seconds=180):
        self.executable = executable or shutil.which("kaggle")
        self.env = dict(os.environ if env is None else env)
        self.timeout_seconds = int(timeout_seconds)
        if self.timeout_seconds < 1 or self.timeout_seconds > 3600:
            raise ValueError("timeout_seconds must be in [1, 3600]")

    def _binary(self):
        if not self.executable:
            raise KaggleJobError("Kaggle CLI is not installed; install the official kaggle package in your environment")
        return str(self.executable)

    def _run(self, args, timeout=None):
        cmd = [self._binary(), *map(str, args)]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout or self.timeout_seconds,
                                    check=False, shell=False, env=self.env)
        except subprocess.TimeoutExpired as exc:
            raise KaggleJobError(f"Kaggle CLI timed out after {exc.timeout}s") from exc
        except OSError as exc:
            raise KaggleJobError(f"Kaggle CLI could not start: {type(exc).__name__}") from exc
        if result.returncode:
            # Never surface raw CLI stderr/stdout; diagnostics can contain account metadata.
            raise KaggleJobError(f"Kaggle CLI failed (exit {result.returncode}); inspect your local Kaggle CLI configuration")
        return result.stdout.strip()

    @staticmethod
    def prepare_kernel_metadata(kernel_dir, metadata):
        root = Path(kernel_dir).resolve(strict=True)
        if not root.is_dir():
            raise ValueError("kernel_dir must be a directory")
        required = {"id", "title", "code_file", "language", "kernel_type", "is_private"}
        if required - set(metadata):
            raise ValueError(f"missing kernel metadata fields: {sorted(required-set(metadata))}")
        slug = metadata["id"]
        if not isinstance(slug, str) or not re.fullmatch(r"[A-Za-z0-9_-]+/[A-Za-z0-9_-]+", slug):
            raise ValueError("id must use Kaggle owner/kernel slug syntax")
        code = (root / metadata["code_file"]).resolve(strict=False)
        if code.parent != root or not code.is_file() or code.suffix.lower() not in {".ipynb", ".py"}:
            raise ValueError("code_file must be a direct .ipynb or .py file in kernel_dir")
        if metadata["language"] not in {"python", "r"}:
            raise ValueError("unsupported Kaggle kernel language")
        if metadata["kernel_type"] != "notebook":
            raise ValueError("this client submits Kaggle notebooks only")
        if not isinstance(metadata["is_private"], bool):
            raise ValueError("is_private must be boolean")
        fields = {"id", "title", "code_file", "language", "kernel_type", "is_private",
                  "enable_gpu", "enable_internet", "dataset_sources", "competition_sources",
                  "kernel_sources", "machine_shape"}
        doc = {key: value for key, value in metadata.items() if key in fields}
        path = root / "kernel-metadata.json"
        path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return {"kernel_dir": str(root), "metadata_path": str(path), "kernel_id": slug,
                "gpu_requested": bool(doc.get("enable_gpu", False)),
                "credential_values_included": False}

    def submit(self, kernel_dir, *, confirm_submit=False):
        """Submit with official `kaggle kernels push`; GPU requests consume quota."""
        root = Path(kernel_dir).resolve(strict=True)
        metadata_path = root / "kernel-metadata.json"
        if not root.is_dir() or not metadata_path.is_file():
            raise ValueError("kernel_dir must contain kernel-metadata.json")
        doc = json.loads(metadata_path.read_text(encoding="utf-8"))
        self.prepare_kernel_metadata(root, doc)
        if not confirm_submit:
            raise PermissionError("kernel submission not started; pass confirm_submit=True after reviewing Kaggle account/quota and GPU settings")
        # Official Kaggle CLI push. No shell, UI automation, or direct private API.
        output = self._run(["kernels", "push", "-p", str(root)])
        return {"submitted": True, "kernel_id": doc["id"],
                "gpu_requested": bool(doc.get("enable_gpu", False)),
                "provider_acceptance": "submitted_not_confirmed_running",
                "cli_message": output[-1000:], "remote_actions_performed": True}

    def status(self, kernel_id):
        if not re.fullmatch(r"[A-Za-z0-9_-]+/[A-Za-z0-9_-]+", str(kernel_id)):
            raise ValueError("invalid Kaggle kernel id")
        message = self._run(["kernels", "status", str(kernel_id)])
        return {"kernel_id": str(kernel_id), "status_text": message[-1000:],
                "remote_actions_performed": True}

    def download_output(self, kernel_id, destination_dir):
        if not re.fullmatch(r"[A-Za-z0-9_-]+/[A-Za-z0-9_-]+", str(kernel_id)):
            raise ValueError("invalid Kaggle kernel id")
        dest = Path(destination_dir).resolve()
        dest.mkdir(parents=True, exist_ok=True)
        message = self._run(["kernels", "output", str(kernel_id), "-p", str(dest)])
        files = [str(p) for p in dest.rglob("*") if p.is_file()]
        return {"kernel_id": str(kernel_id), "destination": str(dest), "files": files,
                "cli_message": message[-1000:], "remote_actions_performed": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser("prepare")
    prepare.add_argument("--kernel-dir", required=True)
    prepare.add_argument("--metadata-json", required=True, help="path to reviewed Kaggle kernel metadata JSON")
    submit = commands.add_parser("submit")
    submit.add_argument("--kernel-dir", required=True)
    submit.add_argument("--confirm-submit", action="store_true", help="allow remote run and possible GPU quota use")
    status = commands.add_parser("status"); status.add_argument("--kernel-id", required=True)
    output = commands.add_parser("output"); output.add_argument("--kernel-id", required=True)
    output.add_argument("--destination", required=True)
    args = parser.parse_args()
    client = KaggleKernelClient()
    if args.command == "prepare":
        doc = json.loads(Path(args.metadata_json).read_text(encoding="utf-8"))
        result = client.prepare_kernel_metadata(args.kernel_dir, doc)
    elif args.command == "submit":
        result = client.submit(args.kernel_dir, confirm_submit=args.confirm_submit)
    elif args.command == "status":
        result = client.status(args.kernel_id)
    else:
        result = client.download_output(args.kernel_id, args.destination)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
