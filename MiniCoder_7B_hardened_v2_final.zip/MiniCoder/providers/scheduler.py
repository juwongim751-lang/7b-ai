"""Honest provider planner: it never launches, switches, or aggregates machines."""
from __future__ import annotations

from providers.registry import ProviderRegistry

PAID_PROVIDERS = {"modal", "lightning"}
MANUAL_NOTEBOOKS = ("kaggle", "colab")


class ProviderScheduler:
    """Choose a usable current runtime or return an explicit manual setup plan.

    Kaggle/Colab notebooks must be started by the user. This scheduler cannot
    submit them through an external controller. Different machines are never
    treated as one combined VRAM pool.
    """
    def __init__(self, registry=None):
        self.registry = registry or ProviderRegistry()

    def plan(self, required_vram_bytes=0, required_ram_bytes=0,
             required_storage_bytes=0, allow_paid=False,
             max_budget_usd=None, estimated_gpu_rate_usd_per_hour=None):
        observed = self.registry.inspect_all()
        current = observed.get("current_process", {})
        provider = current.get("provider", "local")
        provider = {"huggingface_space": "huggingface_zerogpu"}.get(provider, provider)
        reports = observed.get("provider_reports", {})
        row = reports.get(provider, {})
        resources = row.get("runtime_resources", {})
        if provider in PAID_PROVIDERS and not allow_paid:
            usable = False
            reason = "paid provider is disabled by default"
        elif provider == "huggingface_zerogpu":
            usable = False
            reason = "ZeroGPU is treated as short inference/demo compute, not sustained pretraining"
        elif not row.get("runtime_detected", False):
            usable = False
            reason = "no active runtime from this provider is detected"
        elif not resources.get("gpu_available", False):
            usable = False
            reason = "this process has no verified CUDA GPU allocation"
        elif resources.get("vram_free_bytes") is None or resources["vram_free_bytes"] < int(required_vram_bytes):
            usable = False
            reason = "observed free VRAM is below the requested estimate"
        elif resources.get("system_ram_available_bytes") is None or resources["system_ram_available_bytes"] < int(required_ram_bytes):
            usable = False
            reason = "observed available system RAM is below the requested estimate"
        elif resources.get("storage_free_bytes") is None or resources["storage_free_bytes"] < int(required_storage_bytes):
            usable = False
            reason = "observed free storage is below the requested requirement"
        else:
            usable = True
            reason = "current Python process has a verified compatible GPU and local resources"
        cost = None
        cost_gate = {"paid_provider_enabled": bool(allow_paid), "max_budget_usd": max_budget_usd,
                     "estimated_gpu_rate_usd_per_hour": estimated_gpu_rate_usd_per_hour,
                     "can_estimate": bool(max_budget_usd and estimated_gpu_rate_usd_per_hour),
                     "remote_payment_or_job_action_performed": False}
        if provider in PAID_PROVIDERS:
            if not allow_paid or not max_budget_usd or not estimated_gpu_rate_usd_per_hour:
                usable = False
                reason = "paid runtime requires explicit user approval, current rate and budget"
            else:
                cost = {"rate_usd_per_hour": float(estimated_gpu_rate_usd_per_hour),
                        "budget_usd": float(max_budget_usd),
                        "estimated_gpu_seconds": float(max_budget_usd) * 3600 / float(estimated_gpu_rate_usd_per_hour),
                        "note": "GPU-only estimate; not a provider billing cap"}
        if usable:
            selected = {"provider": provider, "action": "train_in_current_process",
                        "gpu_name": resources.get("gpu_name"),
                        "free_vram_bytes": resources.get("vram_free_bytes"),
                        "available_ram_bytes": resources.get("system_ram_available_bytes"),
                        "storage_free_bytes": resources.get("storage_free_bytes"),
                        "session_limit_seconds": resources.get("session_limit_seconds"),
                        "expected_duration_seconds": resources.get("expected_duration_seconds"),
                        "checkpoint_transfer": "save to verified mounted/user-managed storage; transfer not automatic"}
        else:
            selected = None
        manual = []
        for name in MANUAL_NOTEBOOKS:
            manual.append({"provider": name, "action": "user_must_open_and_start_notebook",
                           "remote_submission_api": False,
                           "note": "Rerun this planner inside the notebook to inspect its actual GPU, RAM and free disk; account quotas/session availability are unknown here."})
        return {"selected": selected, "reason": reason, "manual_notebook_options": manual,
                "cost_gate": cost_gate, "estimated_cost": cost,
                "machine_pooling": False, "remote_actions_performed": False,
                "observed_current_provider": provider,
                "note": "No provider is switched or launched by this planner. Expected duration and session limit require account/runtime-specific data and are not guessed."}
