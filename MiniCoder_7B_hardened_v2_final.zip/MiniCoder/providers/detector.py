"""Local runtime/environment detection. It never probes remote accounts or quotas."""
from __future__ import annotations

import os
import shutil
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Mapping, Optional


def _system_memory_bytes():
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.total), int(vm.available)
    except Exception:
        try:
            pages = os.sysconf("SC_PHYS_PAGES")
            page_size = os.sysconf("SC_PAGE_SIZE")
            total = int(pages * page_size)
            return total, None
        except (AttributeError, OSError, ValueError):
            return None, None


@dataclass(frozen=True)
class EnvironmentInfo:
    provider: str
    signals: tuple[str, ...]
    gpu_available: bool
    gpu_name: Optional[str]
    vram_total_bytes: Optional[int]
    vram_free_bytes: Optional[int]
    torch_version: Optional[str]
    cuda_runtime: Optional[str]
    system_ram_total_bytes: Optional[int] = None
    system_ram_available_bytes: Optional[int] = None
    storage_path: Optional[str] = None
    storage_free_bytes: Optional[int] = None
    cuda_device_count: Optional[int] = None
    local_training_process_possible: bool = False
    quota_visibility: str = "not_available_locally"
    remote_job_submission: bool = False

    @property
    def cuda_version(self):
        """Backward-compatible name for the CUDA runtime bundled with PyTorch."""
        return self.cuda_runtime

    def to_dict(self):
        return asdict(self)


def detect_environment(environ: Optional[Mapping[str, str]] = None,
                       torch_module=None) -> EnvironmentInfo:
    """Detect known environment and resources of this running process only.

    A provider label never implies actual GPU allocation. GPU values are read
    only from an active local PyTorch CUDA runtime; account quotas are not read.
    """
    env = os.environ if environ is None else environ
    signals = []
    if env.get("KAGGLE_KERNEL_RUN_TYPE") or env.get("KAGGLE_URL_BASE") or Path("/kaggle").exists():
        provider = "kaggle"
        for key in ("KAGGLE_KERNEL_RUN_TYPE", "KAGGLE_URL_BASE"):
            if env.get(key): signals.append(key)
        if Path("/kaggle").exists(): signals.append("/kaggle")
    elif env.get("COLAB_RELEASE_TAG") or env.get("COLAB_GPU") or Path("/content").exists():
        provider = "colab"
        for key in ("COLAB_RELEASE_TAG", "COLAB_GPU"):
            if env.get(key): signals.append(key)
        if Path("/content").exists(): signals.append("/content")
    elif env.get("LIGHTNING_STUDIO") or env.get("LIGHTNING_CLOUD_PROJECT_ID"):
        provider = "lightning"
        signals.extend(k for k in ("LIGHTNING_STUDIO", "LIGHTNING_CLOUD_PROJECT_ID") if env.get(k))
    elif env.get("SPACE_ID") or env.get("HF_SPACE_ID"):
        provider = "huggingface_space"
        signals.extend(k for k in ("SPACE_ID", "HF_SPACE_ID") if env.get(k))
    elif env.get("MODAL_TASK_ID") or env.get("MODAL_IS_REMOTE"):
        provider = "modal"
        signals.extend(k for k in ("MODAL_TASK_ID", "MODAL_IS_REMOTE") if env.get(k))
    else:
        provider = "local"
        signals.append("fallback")

    if torch_module is None:
        try:
            import torch as torch_module
        except ImportError:
            torch_module = None
    available, name, total, free, count = False, None, None, None, None
    version = getattr(torch_module, "__version__", None) if torch_module else None
    cuda_runtime = getattr(getattr(torch_module, "version", None), "cuda", None) if torch_module else None
    if torch_module is not None:
        try:
            available = bool(torch_module.cuda.is_available())
            if available:
                count_method = getattr(torch_module.cuda, "device_count", None)
                count = int(count_method()) if callable(count_method) else 1
                idx = torch_module.cuda.current_device()
                name = torch_module.cuda.get_device_name(idx)
                free, total = torch_module.cuda.mem_get_info(idx)
                free, total = int(free), int(total)
        except Exception:
            available, name, total, free, count = False, None, None, None, None
    ram_total, ram_available = _system_memory_bytes()
    try:
        storage_path = str(Path.cwd().resolve())
        storage_free = int(shutil.disk_usage(storage_path).free)
    except (OSError, RuntimeError):
        storage_path, storage_free = None, None
    return EnvironmentInfo(
        provider=provider, signals=tuple(signals), gpu_available=available, gpu_name=name,
        vram_total_bytes=total, vram_free_bytes=free, torch_version=version, cuda_runtime=cuda_runtime,
        system_ram_total_bytes=ram_total, system_ram_available_bytes=ram_available,
        storage_path=storage_path, storage_free_bytes=storage_free, cuda_device_count=count,
        local_training_process_possible=bool(torch_module is not None),
    )
