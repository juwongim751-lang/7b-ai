"""Inspection-only adapter for the process currently executing MiniCoder."""
from __future__ import annotations

import os
import shlex
import shutil
from pathlib import Path

from providers.base import BaseProvider
from providers.detector import detect_environment


class LocalProvider(BaseProvider):
    def __init__(self, working_path: str | Path | None = None):
        super().__init__("local")
        self.working_path = Path(working_path or Path.cwd())

    def setup_environment(self):
        env = detect_environment()
        return {"provider": "local", "runtime_detected": True,
                "system": {"ram_total_bytes": env.system_ram_total_bytes,
                           "ram_available_bytes": env.system_ram_available_bytes,
                           "storage_path": env.storage_path,
                           "storage_free_bytes": env.storage_free_bytes},
                "gpu": {"available": env.gpu_available, "name": env.gpu_name,
                        "vram_total_bytes": env.vram_total_bytes,
                        "vram_free_bytes": env.vram_free_bytes,
                        "cuda_version": env.cuda_runtime, "torch_version": env.torch_version,
                        "device_count": env.cuda_device_count},
                "execution": {"training_process_possible": env.local_training_process_possible,
                              "session_limit_seconds": None,
                              "session_limit_note": "Not imposed by this local inspector; host policy is unknown.",
                              "expected_duration_seconds": None,
                              "duration_note": "Requires a benchmark on this model/config/device."},
                "paths": {"working": str(self.working_path),
                          "exists": self.working_path.is_dir(),
                          "writable": self.working_path.is_dir() and os.access(self.working_path, os.W_OK)},
                "capabilities": {"inspect_local_runtime": True, "inspect_local_gpu": True,
                                 "local_training": True, "persistent_storage_verified": False,
                                 "submit_cloud_job": False, "inspect_cloud_credits_or_quota": False}}

    def get_storage_path(self) -> str:
        return str(self.working_path / "checkpoints")

    def run_worker_command(self, rank: int, world_size: int, master_addr: str, master_port: int):
        if int(rank) != 0 or int(world_size) != 1:
            raise NotImplementedError("Local adapter supports only one local process")
        executable = shutil.which("torchrun")
        if not executable:
            raise NotImplementedError("torchrun is not installed in this local process")
        port = int(master_port)
        if not 1 <= port <= 65535 or not str(master_addr).strip():
            raise ValueError("master address or port is invalid")
        return shlex.join([executable, "--nproc_per_node=1", "--nnodes=1", "--node_rank=0",
                           f"--master_addr={master_addr}", f"--master_port={port}", "training/trainer.py"])
