"""Offline checks for the process that is already running."""
from __future__ import annotations

import importlib.util
import shutil
from pathlib import Path

from providers.detector import detect_environment


def runtime_healthcheck(checkpoint_dir: str | Path | None = None) -> dict:
    env = detect_environment()
    try:
        import torch
        torch_version = torch.__version__
    except ImportError:
        torch_version = None
    path = Path(checkpoint_dir) if checkpoint_dir else None
    storage = {"path": str(path), "exists": path.is_dir() if path else None,
               "free_bytes": shutil.disk_usage(path).free if path and path.exists() else None}
    return {
        "environment": env.to_dict(),
        "dependencies": {name: importlib.util.find_spec(name) is not None
                         for name in ("torch", "yaml", "numpy", "safetensors", "modal", "huggingface_hub")},
        "torch_version": torch_version,
        "storage": storage,
        "remote_account_access": False,
        "remote_quota_lookup": False,
    }
