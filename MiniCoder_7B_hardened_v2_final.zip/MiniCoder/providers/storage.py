"""Storage plugin interfaces for already-mounted persistent directories.

No cloud SDK, upload, authentication, or billing operation is performed here.
"""
from __future__ import annotations

import hashlib
import os
import shutil
from abc import ABC, abstractmethod
from pathlib import Path, PurePosixPath
from typing import Dict, Optional


class StorageBackend(ABC):
    name = "storage"

    @abstractmethod
    def save(self, relative_path: str, source: str | Path) -> Dict:
        raise NotImplementedError

    @abstractmethod
    def restore(self, relative_path: str, destination: str | Path, expected_sha256: Optional[str] = None) -> Dict:
        raise NotImplementedError


class DirectoryStorage(StorageBackend):
    """Atomic, bounded storage within an existing local/mounted root directory."""
    def __init__(self, root: str | Path, max_bytes: int = 100 * 1024**3, name: str = "directory"):
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise FileNotFoundError(f"storage root is not mounted or does not exist: {self.root}")
        if max_bytes < 1:
            raise ValueError("max_bytes must be positive")
        self.max_bytes, self.name = int(max_bytes), name

    @staticmethod
    def _relative(path: str) -> Path:
        posix = PurePosixPath(path)
        if posix.is_absolute() or not posix.parts or any(p in {"..", ""} for p in posix.parts):
            raise ValueError("storage path must be a safe relative path")
        return Path(*posix.parts)

    def _target(self, relative_path: str) -> Path:
        target = (self.root / self._relative(relative_path)).resolve()
        try:
            target.relative_to(self.root)
        except ValueError as exc:
            raise ValueError("storage target escapes its root") from exc
        return target

    @staticmethod
    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                h.update(block)
        return h.hexdigest()

    def save(self, relative_path: str, source: str | Path) -> Dict:
        src = Path(source).resolve(strict=True)
        if not src.is_file():
            raise ValueError("source must be a regular file")
        size = src.stat().st_size
        if size > self.max_bytes:
            raise OSError(f"file size {size} exceeds storage limit {self.max_bytes}")
        target = self._target(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + f".partial.{os.getpid()}")
        try:
            with src.open("rb") as input_file, tmp.open("wb") as output_file:
                shutil.copyfileobj(input_file, output_file, 1024 * 1024)
                output_file.flush()
                os.fsync(output_file.fileno())
            digest = self._sha256(src)
            if self._sha256(tmp) != digest:
                raise IOError("storage copy checksum mismatch")
            os.replace(tmp, target)
        finally:
            tmp.unlink(missing_ok=True)
        return {"backend": self.name, "path": str(target), "size_bytes": size,
                "sha256": digest, "integrity": "verified"}

    def restore(self, relative_path: str, destination: str | Path,
                expected_sha256: Optional[str] = None) -> Dict:
        src = self._target(relative_path)
        if not src.is_file():
            raise FileNotFoundError(src)
        digest = self._sha256(src)
        if expected_sha256 and digest.lower() != expected_sha256.lower():
            raise IOError("stored file checksum mismatch")
        dst = Path(destination).resolve()
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + f".partial.{os.getpid()}")
        try:
            with src.open("rb") as input_file, tmp.open("wb") as output_file:
                shutil.copyfileobj(input_file, output_file, 1024 * 1024)
                output_file.flush()
                os.fsync(output_file.fileno())
            if self._sha256(tmp) != digest:
                raise IOError("restore checksum mismatch")
            os.replace(tmp, dst)
        finally:
            tmp.unlink(missing_ok=True)
        return {"backend": self.name, "path": str(dst), "size_bytes": dst.stat().st_size,
                "sha256": digest, "integrity": "verified"}


def colab_drive_storage(max_bytes: int = 100 * 1024**3) -> DirectoryStorage:
    root = Path("/content/drive/MyDrive")
    if not root.is_dir():
        raise RuntimeError("Google Drive is not mounted; mount it in Colab before using this backend")
    return DirectoryStorage(root, max_bytes=max_bytes, name="colab_drive_mounted_directory")


def kaggle_output_storage(max_bytes: int = 100 * 1024**3) -> DirectoryStorage:
    root = Path("/kaggle/working")
    if not root.is_dir():
        raise RuntimeError("Kaggle output directory is not available in this runtime")
    return DirectoryStorage(root, max_bytes=max_bytes, name="kaggle_working_directory")


def modal_volume_storage(mount_path: str | Path = "/checkpoints",
                         max_bytes: int = 100 * 1024**3) -> DirectoryStorage:
    """Use a Modal Volume only after the user has mounted it in the running process."""
    return DirectoryStorage(mount_path, max_bytes=max_bytes, name="modal_volume_mounted_directory")


class HuggingFaceHubStorage(StorageBackend):
    """Optional private-repo checkpoint storage; all network calls are explicit and gated."""
    name = "huggingface_hub"

    def __init__(self, repo_id: str, repo_type: str = "dataset", max_bytes: int = 20 * 1024**3,
                 token_env: str = "HF_TOKEN"):
        if not repo_id or "/" not in repo_id or ".." in repo_id:
            raise ValueError("repo_id must be an explicit namespace/name")
        if repo_type not in {"model", "dataset", "space"}:
            raise ValueError("repo_type must be model, dataset, or space")
        if max_bytes < 1:
            raise ValueError("max_bytes must be positive")
        self.repo_id, self.repo_type = repo_id, repo_type
        self.max_bytes, self.token_env = int(max_bytes), token_env

    def _token(self) -> str:
        token = os.getenv(self.token_env)
        if not token:
            raise PermissionError(f"set {self.token_env} in the environment; interactive login is disabled")
        return token

    def save(self, relative_path: str, source: str | Path, *, confirm_upload: bool = False) -> Dict:
        if not confirm_upload:
            raise PermissionError("remote upload blocked; explicitly pass confirm_upload=True after reviewing repo visibility and terms")
        rel = DirectoryStorage._relative(relative_path).as_posix()
        src = Path(source).resolve(strict=True)
        if not src.is_file():
            raise ValueError("source must be a regular file")
        size = src.stat().st_size
        if size > self.max_bytes:
            raise OSError(f"file size {size} exceeds storage limit {self.max_bytes}")
        token = self._token()
        try:
            from huggingface_hub import HfApi
        except ImportError as exc:
            raise RuntimeError("install optional huggingface_hub to use remote storage") from exc
        # Create private by default; any repo visibility change is left to the owner.
        api = HfApi(token=token)
        api.create_repo(repo_id=self.repo_id, repo_type=self.repo_type, private=True, exist_ok=True)
        result = api.upload_file(path_or_fileobj=str(src), path_in_repo=rel, repo_id=self.repo_id,
                                 repo_type=self.repo_type, commit_message="Save MiniCoder checkpoint")
        return {"backend": self.name, "repo_id": self.repo_id, "repo_type": self.repo_type,
                "path": rel, "size_bytes": size, "sha256": DirectoryStorage._sha256(src),
                "revision": getattr(result, "oid", None), "integrity": "local_source_hashed",
                "visibility": "private_requested", "secret_values_exposed": False}

    def restore(self, relative_path: str, destination: str | Path,
                expected_sha256: Optional[str] = None, *, confirm_download: bool = False) -> Dict:
        if not confirm_download:
            raise PermissionError("remote download blocked; explicitly pass confirm_download=True")
        rel = DirectoryStorage._relative(relative_path).as_posix()
        token = self._token()
        try:
            from huggingface_hub import hf_hub_download
        except ImportError as exc:
            raise RuntimeError("install optional huggingface_hub to use remote storage") from exc
        cached = Path(hf_hub_download(repo_id=self.repo_id, filename=rel, repo_type=self.repo_type, token=token))
        digest = DirectoryStorage._sha256(cached)
        if expected_sha256 and digest.lower() != expected_sha256.lower():
            raise IOError("downloaded checkpoint checksum mismatch")
        dst = Path(destination).resolve()
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + f".partial.{os.getpid()}")
        try:
            with cached.open("rb") as input_file, tmp.open("wb") as output_file:
                shutil.copyfileobj(input_file, output_file, 1024 * 1024)
                output_file.flush()
                os.fsync(output_file.fileno())
            if DirectoryStorage._sha256(tmp) != digest:
                raise IOError("download copy checksum mismatch")
            os.replace(tmp, dst)
        finally:
            tmp.unlink(missing_ok=True)
        return {"backend": self.name, "repo_id": self.repo_id, "path": str(dst),
                "size_bytes": dst.stat().st_size, "sha256": digest, "integrity": "verified"}
