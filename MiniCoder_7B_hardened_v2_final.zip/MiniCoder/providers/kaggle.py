from collections.abc import Mapping
import importlib
import os
from pathlib import Path
import shlex
import shutil
import subprocess
from typing import Any

from providers.base import BaseProvider


_UNSET = object()

class KaggleProvider(BaseProvider):
    """Inspect Kaggle runtime indicators and local resources safely."""

    def __init__(
        self,
        env: Mapping[str, str] | None = None,
        working_path: str | os.PathLike[str] = "/kaggle/working",
        input_path: str | os.PathLike[str] = "/kaggle/input",
        credential_file_path: str | os.PathLike[str] | None = "~/.kaggle/kaggle.json",
        torch_module: Any = _UNSET,
        nvidia_smi_path: str | None | object = _UNSET,
    ):
        super().__init__("kaggle")
        self._env = os.environ if env is None else env
        self.working_path = Path(working_path)
        self.input_path = Path(input_path)
        self.credential_file_path = (
            Path(credential_file_path).expanduser() if credential_file_path is not None else None
        )
        self._torch_module = torch_module
        self._nvidia_smi_path = nvidia_smi_path

    @staticmethod
    def _is_set(env: Mapping[str, str], key: str) -> bool:
        value = env.get(key)
        return value is not None and bool(str(value).strip())

    def detect_runtime(self) -> dict[str, Any]:
        """Return deterministic runtime indicators without exposing env values."""
        indicators = {
            "kernel_run_type": self._is_set(self._env, "KAGGLE_KERNEL_RUN_TYPE"),
            "url_base": self._is_set(self._env, "KAGGLE_URL_BASE"),
        }
        return {"detected": any(indicators.values()), "indicators": indicators}

    def _get_torch(self) -> Any | None:
        if self._torch_module is not _UNSET:
            return self._torch_module
        try:
            return importlib.import_module("torch")
        except Exception:
            # Optional or incomplete torch installations should not break inspection.
            return None

    def _inspect_torch(self) -> dict[str, Any]:
        torch = self._get_torch()
        if torch is None:
            return {
                "available": False,
                "cuda_available": None,
                "device_count": None,
                "devices": [],
            }
        result: dict[str, Any] = {
            "available": True,
            "cuda_available": False,
            "device_count": 0,
            "devices": [],
        }
        try:
            cuda = torch.cuda
            result["cuda_available"] = bool(cuda.is_available())
            if result["cuda_available"]:
                count = int(cuda.device_count())
                result["device_count"] = count
                for index in range(count):
                    try:
                        name = str(cuda.get_device_name(index))
                    except Exception:
                        name = None
                    result["devices"].append({"index": index, "name": name})
        except Exception:
            result["cuda_available"] = None
            result["device_count"] = None
            result["devices"] = []
            result["inspection_error"] = "torch_cuda_inspection_failed"
        return result

    def _find_nvidia_smi(self) -> str | None:
        if self._nvidia_smi_path is not _UNSET:
            return self._nvidia_smi_path
        return shutil.which("nvidia-smi")

    def _inspect_nvidia_smi(self) -> dict[str, Any]:
        executable = self._find_nvidia_smi()
        if not executable:
            return {"available": False, "devices": []}
        query = [
            str(executable),
            "--query-gpu=name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ]
        try:
            completed = subprocess.run(
                query,
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            return {"available": True, "query_succeeded": False, "devices": []}
        if completed.returncode != 0:
            return {"available": True, "query_succeeded": False, "devices": []}
        devices = []
        for line in completed.stdout.splitlines():
            fields = [part.strip() for part in line.split(",", 2)]
            if len(fields) != 3:
                continue
            name, total, free = fields
            devices.append({"name": name, "memory_total_mib": total, "memory_free_mib": free})
        return {"available": True, "query_succeeded": True, "devices": devices}

    def _credential_presence(self) -> dict[str, bool]:
        """Report credential source presence only; never read credential contents."""
        env_username = self._is_set(self._env, "KAGGLE_USERNAME")
        env_key = self._is_set(self._env, "KAGGLE_KEY")
        config_file = False
        if self.credential_file_path is not None:
            try:
                config_file = self.credential_file_path.is_file()
            except OSError:
                config_file = False
        return {
            "username_environment_variable_present": env_username,
            "key_environment_variable_present": env_key,
            "environment_credentials_present": env_username and env_key,
            "credential_file_present": config_file,
        }

    def inspect_runtime(self) -> dict[str, Any]:
        """Inspect this process, conventional Kaggle paths, credentials, and GPU."""
        detection = self.detect_runtime()
        torch_info = self._inspect_torch()
        nvidia_info = self._inspect_nvidia_smi()
        storage_path = self.get_storage_path()
        torchrun_available = bool(shutil.which("torchrun"))
        return {
            "provider": self.provider_name,
            "runtime_detected": detection["detected"],
            "indicators": detection["indicators"],
            "paths": {
                "input": {"path": str(self.input_path), "exists": self.input_path.is_dir()},
                "working": {"path": str(self.working_path), "exists": self.working_path.is_dir()},
                "output": {"path": storage_path, "exists": Path(storage_path).is_dir()},
                "checkpoint_storage": storage_path,
            },
            "credentials": self._credential_presence(),
            "gpu": {"torch": torch_info, "nvidia_smi": nvidia_info},
            "capabilities": {
                "inspect_local_runtime": True,
                "inspect_local_gpu": True,
                "read_local_input_directory": self.input_path.is_dir(),
                "write_local_working_directory": self.working_path.is_dir() and os.access(self.working_path, os.W_OK),
                "generate_local_worker_command": bool(detection["detected"] and torchrun_available),
                "execute_worker_command": False,
                "submit_cloud_job": False,
                "access_external_kaggle_session": False,
                "persistent_storage_verified": False,
            },
        }

    def setup_environment(self):
        """Inspect only; deliberately do not install or mutate anything."""
        return self.inspect_runtime()

    def get_storage_path(self) -> str:
        """Return the conventional Kaggle output location without creating it."""
        return str(self.working_path / "minicoder_output")

    def run_worker_command(self, rank, world_size, master_addr, master_port):
        """Build, but never run, a command for one worker in this local runtime."""
        if not self.detect_runtime()["detected"]:
            raise NotImplementedError(
                "No Kaggle runtime was detected; this adapter cannot invoke an external session."
            )
        if int(rank) != 0 or int(world_size) != 1:
            raise NotImplementedError("Only a single local worker is supported; multi-node work is unsupported.")
        executable = shutil.which("torchrun")
        if not executable:
            raise NotImplementedError("torchrun is not installed in the current process environment.")
        port = int(master_port)
        if not 1 <= port <= 65535:
            raise ValueError("master_port must be between 1 and 65535")
        if not str(master_addr).strip():
            raise ValueError("master_addr must not be empty")
        args = [
            executable,
            "--nproc_per_node=1",
            "--nnodes=1",
            "--node_rank=0",
            f"--master_addr={master_addr}",
            f"--master_port={port}",
            "training/trainer.py",
        ]
        return shlex.join(args)


# Backward-compatible import path; implementation lives in providers.colab.
from providers.colab import ColabProvider
