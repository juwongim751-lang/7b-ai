"""Local-only Hugging Face Spaces / ZeroGPU context inspection.

ZeroGPU is classified here as an inference, demo, or short-evaluation target,
not a long-pretraining provider. This adapter makes no API calls, installs no
packages, and never submits or executes a cloud job. A Space environment marker
alone does not mean a ZeroGPU allocation is active; callers must explicitly
supply ``zerogpu_context_active=True`` for the current decorated execution
context, and a GPU must also be locally observable before an allocation is
reported as observed.
"""
from collections.abc import Mapping
import importlib
import os
from pathlib import Path
import shutil
import subprocess
from typing import Any

from providers.base import BaseProvider


_UNSET = object()


class HuggingFaceZeroGPUProvider(BaseProvider):
    """Detect local HF Spaces markers and report verified local capabilities."""

    def __init__(
        self,
        env: Mapping[str, str] | None = None,
        working_path: str | os.PathLike[str] = "/tmp",
        torch_module: Any = _UNSET,
        nvidia_smi_path: str | None | object = _UNSET,
        zerogpu_context_active: bool = False,
    ):
        super().__init__("huggingface_zerogpu")
        self._env = os.environ if env is None else env
        self.working_path = Path(working_path)
        self._torch_module = torch_module
        self._nvidia_smi_path = nvidia_smi_path
        self._zerogpu_context_active = bool(zerogpu_context_active)

    @staticmethod
    def _is_set(env: Mapping[str, str], key: str) -> bool:
        value = env.get(key)
        return value is not None and bool(str(value).strip())

    def detect_runtime(self) -> dict[str, Any]:
        """Detect a Space only from its local process environment markers."""
        indicators = {
            "space_id": self._is_set(self._env, "SPACE_ID"),
            "space_host": self._is_set(self._env, "SPACE_HOST"),
        }
        return {"detected": any(indicators.values()), "indicators": indicators}

    def _get_torch(self) -> Any | None:
        if self._torch_module is not _UNSET:
            return self._torch_module
        try:
            return importlib.import_module("torch")
        except Exception:
            # Torch may be absent or fail to load due to missing native libraries.
            return None

    def _inspect_torch(self) -> dict[str, Any]:
        torch = self._get_torch()
        if torch is None:
            return {
                "available": False,
                "cuda_available": None,
                "device_count": None,
                "devices": [],
            }
        result: dict[str, Any] = {
            "available": True,
            "cuda_available": False,
            "device_count": 0,
            "devices": [],
        }
        try:
            cuda = torch.cuda
            result["cuda_available"] = bool(cuda.is_available())
            if result["cuda_available"]:
                count = int(cuda.device_count())
                result["device_count"] = count
                for index in range(count):
                    try:
                        name = str(cuda.get_device_name(index))
                    except Exception:
                        name = None
                    result["devices"].append({"index": index, "name": name})
        except Exception:
            result["cuda_available"] = None
            result["device_count"] = None
            result["devices"] = []
            result["inspection_error"] = "torch_cuda_inspection_failed"
        return result

    def _find_nvidia_smi(self) -> str | None:
        if self._nvidia_smi_path is not _UNSET:
            return self._nvidia_smi_path
        return shutil.which("nvidia-smi")

    def _inspect_nvidia_smi(self) -> dict[str, Any]:
        executable = self._find_nvidia_smi()
        if not executable:
            return {"available": False, "devices": []}
        query = [
            str(executable),
            "--query-gpu=name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ]
        try:
            completed = subprocess.run(
                query,
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            return {"available": True, "query_succeeded": False, "devices": []}
        if completed.returncode != 0:
            return {"available": True, "query_succeeded": False, "devices": []}
        devices = []
        for line in completed.stdout.splitlines():
            fields = [part.strip() for part in line.split(",", 2)]
            if len(fields) != 3:
                continue
            name, total, free = fields
            devices.append({"name": name, "memory_total_mib": total, "memory_free_mib": free})
        return {"available": True, "query_succeeded": True, "devices": devices}

    @staticmethod
    def _has_local_gpu(torch_info: Mapping[str, Any], nvidia_info: Mapping[str, Any]) -> bool:
        torch_gpu = torch_info.get("cuda_available") is True and int(torch_info.get("device_count") or 0) > 0
        nvidia_gpu = bool(nvidia_info.get("query_succeeded") and nvidia_info.get("devices"))
        return torch_gpu or nvidia_gpu

    def inspect_runtime(self) -> dict[str, Any]:
        """Return a capability report based only on this process and local tools."""
        detection = self.detect_runtime()
        torch_info = self._inspect_torch()
        nvidia_info = self._inspect_nvidia_smi()
        local_gpu_observed = self._has_local_gpu(torch_info, nvidia_info)
        active_space_context = bool(detection["detected"] and self._zerogpu_context_active)
        allocation_observed = bool(active_space_context and local_gpu_observed)
        storage_path = self.get_storage_path()
        return {
            "provider": self.provider_name,
            "runtime_detected": detection["detected"],
            "indicators": detection["indicators"],
            "workload_classification": "inference_demo_short_evaluation",
            "long_pretraining_supported": False,
            "paths": {
                "working": {
                    "path": str(self.working_path),
                    "exists": self.working_path.is_dir(),
                    "writable": self.working_path.is_dir() and os.access(self.working_path, os.W_OK),
                },
                "checkpoint_storage": {
                    "path": storage_path,
                    "exists": Path(storage_path).is_dir(),
                    "persistent": False,
                },
            },
            "gpu": {
                "torch": torch_info,
                "nvidia_smi": nvidia_info,
                "local_gpu_observed": local_gpu_observed,
                "zerogpu_execution_context_active": active_space_context,
                "zerogpu_allocation_observed": allocation_observed,
            },
            "capabilities": {
                "inspect_local_runtime": True,
                "inspect_local_gpu": True,
                "write_local_working_directory": self.working_path.is_dir() and os.access(self.working_path, os.W_OK),
                "persistent_storage_verified": False,
                "generate_local_worker_command": False,
                "execute_worker_command": False,
                "submit_cloud_job": False,
                "access_external_huggingface_space": False,
                "long_pretraining": False,
            },
            "limitations": [
                "ZeroGPU is classified for inference, demos, or short evaluation, not long pretraining.",
                "A Space marker alone does not establish an active ZeroGPU execution context or allocation.",
                "Quota, credits, persistent storage, remote Space access, and cloud submission are not verified.",
            ],
        }

    def setup_environment(self):
        """Inspect only; do not install dependencies or mutate the environment."""
        return self.inspect_runtime()

    def get_storage_path(self) -> str:
        """Return a local temporary path without creating or claiming persistence."""
        return str(self.working_path / "minicoder_output")

    def run_worker_command(self, rank: int, world_size: int, master_addr: str, master_port: int):
        """Reject distributed worker execution, which this adapter does not support."""
        raise NotImplementedError(
            "Hugging Face ZeroGPU is for inference, demos, or short evaluation; "
            "this adapter does not generate or execute training worker commands."
        )
