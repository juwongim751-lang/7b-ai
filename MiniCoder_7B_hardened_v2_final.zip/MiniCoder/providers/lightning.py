"""Inspection-only adapter for a local Lightning AI Studio runtime."""
from collections.abc import Mapping
import importlib
import os
from pathlib import Path
import shlex
import shutil
import subprocess
from typing import Any

from providers.base import BaseProvider


_UNSET = object()


class LightningProvider(BaseProvider):
    """Detect and inspect only the current local Studio process and resources."""

    def __init__(
        self,
        env: Mapping[str, str] | None = None,
        studio_path: str | os.PathLike[str] = "/teamspace/studios/this_studio",
        working_path: str | os.PathLike[str] | None = None,
        torch_module: Any = _UNSET,
        nvidia_smi_path: str | None | object = _UNSET,
    ):
        super().__init__("lightning")
        self._env = os.environ if env is None else env
        self.studio_path = Path(studio_path)
        self.working_path = Path(working_path) if working_path is not None else self.studio_path
        self._torch_module = torch_module
        self._nvidia_smi_path = nvidia_smi_path

    @staticmethod
    def _is_set(env: Mapping[str, str], key: str) -> bool:
        value = env.get(key)
        return value is not None and bool(str(value).strip())

    def detect_runtime(self) -> dict[str, Any]:
        """Report boolean local signals only; environment values are never returned."""
        indicators = {
            "lightning_studio_environment_variable": self._is_set(self._env, "LIGHTNING_STUDIO"),
            "lightning_cloud_project_id_environment_variable": self._is_set(
                self._env, "LIGHTNING_CLOUD_PROJECT_ID"
            ),
            "studio_directory_exists": self.studio_path.is_dir(),
        }
        return {"detected": any(indicators.values()), "indicators": indicators}

    def _get_torch(self) -> Any | None:
        if self._torch_module is not _UNSET:
            return self._torch_module
        try:
            return importlib.import_module("torch")
        except Exception:
            return None

    def _inspect_torch(self) -> dict[str, Any]:
        torch = self._get_torch()
        if torch is None:
            return {"available": False, "cuda_available": None, "device_count": None, "devices": []}
        result: dict[str, Any] = {
            "available": True,
            "cuda_available": False,
            "device_count": 0,
            "devices": [],
        }
        try:
            cuda = torch.cuda
            result["cuda_available"] = bool(cuda.is_available())
            if result["cuda_available"]:
                count = int(cuda.device_count())
                result["device_count"] = count
                for index in range(count):
                    try:
                        name = str(cuda.get_device_name(index))
                    except Exception:
                        name = None
                    result["devices"].append({"index": index, "name": name})
        except Exception:
            result["cuda_available"] = None
            result["device_count"] = None
            result["devices"] = []
            result["inspection_error"] = "torch_cuda_inspection_failed"
        return result

    def _find_nvidia_smi(self) -> str | None:
        if self._nvidia_smi_path is not _UNSET:
            return self._nvidia_smi_path
        return shutil.which("nvidia-smi")

    def _inspect_nvidia_smi(self) -> dict[str, Any]:
        executable = self._find_nvidia_smi()
        if not executable:
            return {"available": False, "devices": []}
        query = [
            str(executable),
            "--query-gpu=name,memory.total,memory.free",
            "--format=csv,noheader,nounits",
        ]
        try:
            completed = subprocess.run(query, capture_output=True, text=True, timeout=3, check=False)
        except (OSError, subprocess.SubprocessError):
            return {"available": True, "query_succeeded": False, "devices": []}
        if completed.returncode != 0:
            return {"available": True, "query_succeeded": False, "devices": []}
        devices = []
        for line in completed.stdout.splitlines():
            fields = [part.strip() for part in line.split(",", 2)]
            if len(fields) == 3:
                name, total, free = fields
                devices.append({"name": name, "memory_total_mib": total, "memory_free_mib": free})
        return {"available": True, "query_succeeded": True, "devices": devices}

    def _credential_presence(self) -> dict[str, bool]:
        """Report the API-key variable's presence, not its value or validity."""
        return {"api_key_environment_variable_present": self._is_set(self._env, "LIGHTNING_CLOUD_API_KEY")}

    def inspect_runtime(self) -> dict[str, Any]:
        """Inspect local indicators, paths, credential-variable presence, and GPU only."""
        detection = self.detect_runtime()
        storage_path = self.get_storage_path()
        torchrun_available = bool(shutil.which("torchrun"))
        return {
            "provider": self.provider_name,
            "runtime_detected": detection["detected"],
            "indicators": detection["indicators"],
            "paths": {
                "studio": {"path": str(self.studio_path), "exists": self.studio_path.is_dir()},
                "working": {"path": str(self.working_path), "exists": self.working_path.is_dir()},
                "output": {"path": storage_path, "exists": Path(storage_path).is_dir()},
                "checkpoint_storage": storage_path,
            },
            "credentials": self._credential_presence(),
            "gpu": {"torch": self._inspect_torch(), "nvidia_smi": self._inspect_nvidia_smi()},
            "capabilities": {
                "inspect_local_runtime": "supported",
                "inspect_local_gpu": "supported",
                "generate_local_worker_command": "supported"
                if detection["detected"] and torchrun_available
                else "unavailable",
                "execute_worker_command": "unsupported",
                "submit_cloud_job": "unsupported",
                "access_remote_studio_or_account": "unsupported",
                "inspect_cloud_credits_or_quota": "unsupported",
                "persistent_storage_verified": False,
            },
        }

    def setup_environment(self):
        """Perform inspection only; do not install packages or mutate the environment."""
        return self.inspect_runtime()

    def get_storage_path(self) -> str:
        """Return a proposed local output path without creating or verifying persistence."""
        return str(self.working_path / "minicoder_output")

    def run_worker_command(self, rank, world_size, master_addr, master_port):
        """Build a local single-worker command; never execute or remotely submit it."""
        if not self.detect_runtime()["detected"]:
            raise NotImplementedError("No local Lightning Studio runtime was detected.")
        if int(rank) != 0 or int(world_size) != 1:
            raise NotImplementedError("Only a single local worker is supported; distributed work is unsupported.")
        executable = shutil.which("torchrun")
        if not executable:
            raise NotImplementedError("torchrun is not installed in the current process environment.")
        port = int(master_port)
        if not 1 <= port <= 65535:
            raise ValueError("master_port must be between 1 and 65535")
        if not str(master_addr).strip():
            raise ValueError("master_addr must not be empty")
        args = [
            executable,
            "--nproc_per_node=1",
            "--nnodes=1",
            "--node_rank=0",
            f"--master_addr={master_addr}",
            f"--master_port={port}",
            "training/trainer.py",
        ]
        return shlex.join(args)
