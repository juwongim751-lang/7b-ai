# Local GPU/CPU benchmark

This report measures the environment running this command only. It does not test cloud account access, quotas, or other providers.

- Detected provider: `local`
- Actual device: `cpu` (N/A)
- Torch / CUDA: `2.15.0+cu132` / `13.2`
- Model config / parameters: `config/model_tiny_10m.yaml` / `10,054,272`
- Batch × sequence: `1 × 16`; measured steps: `5`
- Measured throughput: `181.8` tokens/s
- Peak GPU allocation: `N/A` bytes
- Matrix memory bandwidth: `N/A (not measured)`
- Final synthetic loss: `6.02891`

A small correctness/performance probe, not a provider-wide or 7B throughput estimate.
