# BitNet 참조 경로 및 검증 결과

## 구현 범위

`config/model_bitnet_tiny.yaml`과 `model.bitlinear.BitLinear`는 학습 시 다음 경로를 적용합니다.

- Weight: layer 전체 `abs(weight).mean()` scale로 정규화한 뒤 round/clip하여 `{-1, 0, +1}` ternary forward 값 사용.
- Activation: token별 symmetric 8-bit fake quantize/dequantize reference path.
- Gradient: straight-through estimator로 master floating-point weight로 gradient 역전파.
- Transformer의 선택된 선형층에 `BitLinear`를 사용합니다.

이는 quantization-aware training **reference implementation**입니다. 학습 파라미터와 optimizer는 float로 유지되고, 이 코드는 BitNet 논문의 모든 normalization/scaling details나 고성능 fused integer GEMM을 재현하지 않습니다. 학습·추론의 실측 속도나 품질 이득을 주장하지 않습니다. 자세한 정의·공식 출처는 [`docs/BITNET_REFERENCE.md`](docs/BITNET_REFERENCE.md) 참고.

## Inference-only packed artifact

선택적 `model.export` 경로는 ternary 값을 5개씩 base-3로 묶어 1 byte에 저장합니다(가능 code 0..242). 5개의 ternary weight를 1 byte에 넣으므로 실제 고정 길이 평균은 **1.6 bit/weight**입니다. 텐서별 scale과 나머지 metadata는 별도 보존합니다. Dequantizing reference loader는 이를 원래 모델 구조로 복원합니다.

- 이 포맷은 **inference artifact 전용**이고 optimizer/resume state를 포함하지 않습니다.
- packed forward는 reference dequantization을 수행하며 packed integer GEMM/실행 가속은 없습니다.
- 1.6bit는 순수 ternary payload의 값이고 metadata, JSON config, alignment, 저장 filesystem overhead를 포함하지 않습니다.
- 학습 checkpoint는 별도 단일 PyTorch file이며 float master weights와 optimizer state를 담습니다.

## 재현 검증

실행: `python -m unittest tests.test_bitnet -v`

포함 assertions: absmean ternary 범위·zero, STE gradient, activation quantization 및 gradient, BitLinear forward/backward, Tiny Transformer BitNet, 짧은 toy overfit, checkpoint 왕복, five-trits-per-byte encode/decode, packed/base-model output equality, ternary payload 압축 및 standard/packed export roundtrip.

테스트는 CPU에서 exact/model-mechanics를 검증합니다. CUDA, full 7B training, task quality, energy, throughput, commercial artifacts와 third-party kernel은 검증하지 않았습니다. Project QAT “BitNet-style” 표기는 공식 pretrained BitNet 모델을 의미하지 않습니다.
