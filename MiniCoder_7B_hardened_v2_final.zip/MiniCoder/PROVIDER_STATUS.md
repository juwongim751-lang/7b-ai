# Provider 상태 — Cloud V2

**기준일: 2026-11-05.** 테스트한 것은 모의/CPU 환경의 코드 경로다. 사용자의 cloud 계정에 로그인하거나 실제 GPU 작업·쿼터를 확인하지 않았다. Provider API의 공식 문서 비교는 [`docs/CLOUD_V2_PROVIDER_API_RESEARCH.md`](docs/CLOUD_V2_PROVIDER_API_RESEARCH.md)에 있다.

| Provider | 공식 실행 방식 확인 | 이 프로젝트의 코드 경계 | 확인 상태 |
|---|---|---|---|
| **Kaggle Notebooks** | 공식 Kaggle CLI `kernels push`, `kernels status`, `kernels output`로 batch kernel submission 가능. 별도 stable direct REST submit endpoint는 가정하지 않음. | `providers/kaggle_jobs.py`는 메타데이터 안전검사와 공식 CLI 명령만 사용. `submit`에 명시 `confirm_submit=True` 필요. Dashboard는 인증된 prepare/submit/status/output endpoint를 제공. 크레덴셜은 Kaggle CLI의 사용자 환경에 미리 설정하고 코드/응답에 노출하지 않음. | CLI subprocess shape·consent·metadata path를 mock으로 **PASS**. 실제 Kaggle 자격·쿼터·실행·GPU 결과 **NOT TESTED**. |
| **Google Colab** | Colab API/MCP가 인증된 runtime 생성 및 runtime Jupyter kernel에서 Python 실행을 지원. 기존 `.ipynb` batch submit API는 아님. | 제공 notebook은 사용자가 런타임과 Drive를 직접 선택/마운트하여 10M Tiny fit, checksum resume, export함. 외부 controller Colab OAuth/REST client는 이 코드에 연결하지 않음. | notebook JSON/code syntax, CPU test PASS. 사용자 Google account/GPU/Drive API **NOT TESTED**. |
| **Lightning AI** | SDK/CLI로 Studio·Job 명령 제출. 공식 notebook-cell batch submit은 확인되지 않음. | inspection adapter·문서. Job submit client는 미구현. | mock detection tests PASS; 실제 Studio/크레딧 **NOT TESTED**. |
| **Hugging Face ZeroGPU** | 사전 작성한 Gradio Space 함수 호출 가능. 임의 학습 command/notebook submit API는 아님. | 검사 adapter와 짧은 안전한 추론 예시. 실제 Space 호출은 미구현. Hub checkpoint transport는 별도 사용자 승인 필요. | code path/unit tests PASS; Space 계정/호스팅/GPU **NOT TESTED**. |
| **Modal** | 사전에 배포한 함수의 SDK submit 가능; notebook submit이 아님. | Tiny App은 사용자 `--confirm-potential-cost`, 양수 GPU 요금률과 USD 예산을 요구함. 단가는 코드에 고정하지 않음. | import/static/tests PASS; 배포·결제·GPU run **NOT TESTED**. |
| **Local GPU** | 별도 provider service가 아님. 같은 호스트 프로세스 실행은 가능. | `ProviderRegistry`는 현재 process의 실제 runtime 자원만 검사. `ProviderScheduler`는 현재 실행 중이고 요구량에 맞는 **동일 process GPU**만 선택, 원격 실행은 하지 않음. | CPU/mock tests PASS; 본 실행환경 CUDA GPU 없음. |

## 실행 선택 및 failover

`ProviderScheduler.plan()`은 오직 실제 현재 process의 관찰 가능한 자원 중 한 provider에 할당된 단일 GPU를 선택한다. 자유·유료 원격 worker를 자동으로 시작하지 않고 다른 network/runtime의 GPU 메모리를 더하지 않는다. Kaggle batch submission은 별도의 공식 CLI job path이며 `confirm_submit` 확인 뒤 수동·명시적으로 시작한다. Colab 공식 외부 OAuth runtime client, Lightning remote Job client, generalized cross-provider queue/failover, quota/price/remaining-session aware allocation은 아직 구현되지 않았다.

실제 외부 job은 시작하지 않았다. 각 계정의 현재 자격·쿼터·잔액·사용 가능 GPU/머신 shape는 확인하지 않았다. 커넥터/UI에서 “provider를 바꿨다”는 모의 상태를 보여주지 않는다.
