"""Unit tests for Phases 2-4. Run: python -m unittest tests.test_phase2_4 -v
Torch-dependent tests are skipped (not passed) when torch is missing."""
import json, math, tempfile, unittest
from collections import Counter
from pathlib import Path

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

from dataset.packed import epoch_indices
from dataset.pipeline import (DataConfig, NearDupIndex, build, check_syntax, quality_score, rebalance, Sample,
                              load_samples,
                              tokenize_split, update_manifest_token_counts, explanation_code_overlap,
                              sensitive_content_flags)
from dataset.synthetic import write_smoke_corpus
from dataset.tokenizer import MiniCoderTokenizer, SPECIAL_TOKENS
from model.config import MiniCoderConfig, load_config
from training.config import EarlyStopper, cosine_lr_lambda, load_train_config
from training.metrics import MetricsLogger


class TestConfigs(unittest.TestCase):
    def test_load_all_configs(self):
        n7 = load_config("config/model.yaml").calculate_parameters()
        self.assertEqual(n7, 7_241_732_096)
        self.assertEqual(load_config("config/model_tiny.yaml").tie_word_embeddings, True)

    def test_validation(self):
        with self.assertRaises(ValueError): MiniCoderConfig(hidden_size=100, num_heads=8)
        with self.assertRaises(ValueError): MiniCoderConfig(hidden_size=64, num_heads=8, num_kv_heads=3)
        with self.assertRaises(ValueError): load_train_config(None, bogus=1)

    def test_scheduler_curve(self):
        total = 100
        lrs = [cosine_lr_lambda(s, 10, total, 0.1) for s in range(total)]
        self.assertAlmostEqual(lrs[9], 1.0); self.assertGreater(lrs[0], 0)
        self.assertTrue(all(a >= b - 1e-9 for a, b in zip(lrs[10:], lrs[11:])))
        self.assertAlmostEqual(lrs[-1], 0.1, places=2)
        self.assertLess(cosine_lr_lambda(3, 2000, 10, 0.1), 1.01)   # oversized warmup is clamped

    def test_early_stopper(self):
        es = EarlyStopper(2)
        self.assertFalse(es.update(1.0)); self.assertFalse(es.update(1.1)); self.assertTrue(es.update(1.2))


class TestTokenizer(unittest.TestCase):
    def test_roundtrip_and_specials(self):
        tk = MiniCoderTokenizer(1000); tk.train_from_iterator(["def f(x):\n    return x\n"] * 5)
        text = "def f(x):\n    return '한글 😀 é'\t# \u202e\n"
        self.assertEqual(tk.decode(tk.encode(text)), text)
        self.assertEqual([tk.token_id(t) for t in SPECIAL_TOKENS[:4]], [0, 1, 2, 3])
        ids = tk.encode("x", add_bos=True, add_eos=True)
        self.assertEqual((ids[0], ids[-1]), (tk.bos_token_id, tk.eos_token_id))
        self.assertEqual(tk.token_stats([text])["unk_tokens"], 0)

    def test_save_load(self):
        with tempfile.TemporaryDirectory() as d:
            tk = MiniCoderTokenizer(1000); tk.train_from_iterator(["abc def " * 20] * 5); tk.save(f"{d}/t.json")
            t2 = MiniCoderTokenizer(); t2.load(f"{d}/t.json")
            self.assertEqual(tk.encode("abc def"), t2.encode("abc def")); self.assertEqual(tk.fingerprint(), t2.fingerprint())


class TestPipeline(unittest.TestCase):
    def test_unknown_license_is_excluded_by_default(self):
        with tempfile.TemporaryDirectory() as d:
            unknown=Path(d)/"unknown.txt"; licensed=Path(d)/"licensed.txt"
            unknown.write_text("A sufficiently long source sample with unknown terms.\n",encoding="utf-8")
            licensed.write_text("A different source sample with explicit license terms.\n",encoding="utf-8")
            cfg=DataConfig(sources=[{"path":str(unknown)},{"path":str(licensed),"license":"MIT"}],
                           min_quality=0.0,near_dup=False)
            removed=Counter(); samples=load_samples(cfg,removed)
            self.assertEqual(len(samples),1)
            self.assertEqual(samples[0].license,"MIT")
            self.assertEqual(removed["license_unknown"],1)

    def test_sensitive_scanner_returns_categories_not_matched_values(self):
        fake_token = "ghp_" + "a" * 32
        text = "private_key = '" + fake_token + "'\ncontact = dev@example.com\n-----BEGIN PRIVATE KEY-----"
        flags = sensitive_content_flags(text)
        self.assertIn("known_api_token", flags)
        self.assertIn("email_address", flags)
        self.assertIn("private_key", flags)
        self.assertNotIn(fake_token, repr(flags))

    def test_syntax(self):
        self.assertEqual(check_syntax("def f(:\n", "python"), (False, True))
        self.assertEqual(check_syntax("x = 1\n", "python"), (True, True))
        self.assertEqual(check_syntax("int f(){ return (1; }", "cpp")[0], False)
        self.assertEqual(check_syntax("int f(){ return '(' ; }", "cpp")[0], True)

    def test_quality_not_length_driven(self):
        cfg = DataConfig()
        good = "def add(a, b):\n    return a + b\n\n\ndef sub(a, b):\n    return a - b\n"
        junk = "x = 1\n" * 5000
        qg, _ = quality_score(good, "python", True, "", cfg); qj, _ = quality_score(junk, "python", True, "", cfg)
        self.assertGreater(qg, qj)

    def test_near_dup(self):
        base = " ".join(f"word{i}" for i in range(200))
        idx = NearDupIndex(0.85)
        self.assertFalse(idx.check_and_add(base)); self.assertTrue(idx.check_and_add(base + " extra"))
        self.assertFalse(idx.check_and_add(" ".join(f"other{i}" for i in range(200))))

    def test_overlap_signal(self):
        self.assertGreater(explanation_code_overlap("add numbers total", "def add(total): return total"),
                           explanation_code_overlap("render widget banana", "def add(total): return total"))

    def test_build_split_manifest_and_shards(self):
        with tempfile.TemporaryDirectory() as d:
            planted = write_smoke_corpus(f"{d}/raw", n=80)
            cfg = DataConfig(sources=[{"path": f"{d}/raw/code", "name": "syn", "license": "CC0"},
                                      {"path": f"{d}/raw/pairs.jsonl", "name": "pairs", "license": "CC0"}],
                             out_dir=f"{d}/out", val_ratio=0.1, min_val_samples=5)
            m = build(cfg)
            tr = [json.loads(l) for l in Path(f"{d}/out/train.jsonl").read_text("utf-8").splitlines()]
            va = [json.loads(l) for l in Path(f"{d}/out/val.jsonl").read_text("utf-8").splitlines()]
            self.assertFalse({r["id"] for r in tr} & {r["id"] for r in va})          # no leak
            self.assertGreaterEqual(m["removed"].get("exact_dup", 0), 1)
            self.assertGreaterEqual(m["removed"].get("near_dup", 0), 1)
            self.assertGreaterEqual(m["removed"].get("bad_syntax", 0), 1)
            self.assertIn("CC0", m["train"]["by_license"])
            self.assertGreaterEqual(len(va), 5)
            m2 = build(cfg)                                                              # deterministic
            self.assertEqual(m["dataset_version"], m2["dataset_version"])
            tk = MiniCoderTokenizer(500); tk.train_from_iterator([r["text"] for r in tr])
            meta = tokenize_split(Path(f"{d}/out/train.jsonl"), tk, Path(f"{d}/out/train.bin"), m["dataset_version"])
            val_meta = tokenize_split(Path(f"{d}/out/val.jsonl"), tk, Path(f"{d}/out/val.bin"), m["dataset_version"])
            updated = update_manifest_token_counts(f"{d}/out", {"train": meta, "val": val_meta})
            self.assertEqual(updated["tokenization"]["total_tokens"], meta["n_tokens"] + val_meta["n_tokens"])
            self.assertEqual(updated["tokenization"]["tokenizer_fingerprint"], tk.fingerprint())
            import numpy as np
            arr = np.fromfile(f"{d}/out/train.bin", dtype=meta["dtype"])
            self.assertEqual(len(arr), meta["n_tokens"]); self.assertLess(int(arr.max()), meta["vocab_size"])
            self.assertEqual(int(arr[0]), tk.bos_token_id)

    def test_rebalance(self):
        mk = lambda i, l: Sample(f"{l}{i}", "x", l, "code", "s", "MIT", quality=1 - i / 1000)
        samples = [mk(i, "python") for i in range(90)] + [mk(i, "lua") for i in range(30)]
        cfg = DataConfig(balance_by="lang", balance_targets={"python": 0.5, "lua": 0.5})
        out = rebalance(samples, cfg, Counter())
        c = Counter(s.lang for s in out); self.assertEqual(c["python"], c["lua"])


class TestDataOrdering(unittest.TestCase):
    def test_rank_disjoint_and_deterministic(self):
        n, w = 103, 4
        shards = [epoch_indices(n, 7, 2, r, w) for r in range(w)]
        self.assertEqual(len({len(s) for s in shards}), 1)
        flat = [i for s in shards for i in s.tolist()]
        self.assertEqual(set(flat), set(range(n)))                       # full coverage; only wrap padding repeats
        self.assertLessEqual(len(flat) - n, w - 1)
        self.assertTrue((epoch_indices(n, 7, 2, 1, w) == shards[1]).all())
        self.assertFalse((epoch_indices(n, 7, 3, 1, w) == shards[1]).all())

    def test_metrics_log(self):
        with tempfile.TemporaryDirectory() as d:
            m = MetricsLogger(d); m.log("train", step=1, loss=2.0)
            self.assertEqual(MetricsLogger.read(f"{d}/metrics.jsonl")[0]["step"], 1)


@unittest.skipUnless(HAS_TORCH, "torch not installed")
class TestModel(unittest.TestCase):
    def setUp(self):
        from model.transformer import MiniCoder7B
        torch.manual_seed(0)
        self.cfg = load_config("config/model_tiny.yaml"); self.cfg.tie_word_embeddings = False
        self.m = MiniCoder7B(self.cfg).eval()

    def test_forward_backward_and_param_count(self):
        x = torch.randint(0, self.cfg.vocab_size, (2, 16))
        self.m.train(); out = self.m(x); self.assertEqual(out.shape, (2, 16, self.cfg.vocab_size))
        out.float().mean().backward()
        self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all() for p in self.m.parameters()))
        self.assertEqual(self.m.num_parameters(), self.cfg.calculate_parameters())

    def test_tied_param_count(self):
        from model.transformer import MiniCoder7B
        c = load_config("config/model_tiny.yaml")
        self.assertEqual(MiniCoder7B(c).num_parameters(), c.calculate_parameters())

    def test_causal_no_leak(self):
        x = torch.randint(0, self.cfg.vocab_size, (1, 12)); y = x.clone(); y[0, 8:] = (y[0, 8:] + 1) % self.cfg.vocab_size
        d = (self.m(x)[:, :8] - self.m(y)[:, :8]).abs().max().item(); self.assertLess(d, 1e-5)

    def test_right_padding_invariance(self):
        x = torch.randint(1, self.cfg.vocab_size, (1, 10)); pad = torch.cat([x, torch.zeros(1, 4, dtype=torch.long)], 1)
        mask = torch.cat([torch.ones(1, 10), torch.zeros(1, 4)], 1).long()
        d = (self.m(x) - self.m(pad, attention_mask=mask)[:, :10]).abs().max().item(); self.assertLess(d, 1e-4)

    def test_kv_cache_matches_full_forward(self):
        x = torch.randint(0, self.cfg.vocab_size, (2, 12)); full = self.m(x)
        logits, past = self.m(x[:, :8], use_cache=True)
        steps = [logits]
        for t in range(8, 12):
            lg, past = self.m(x[:, t:t + 1], past_key_values=past, use_cache=True); steps.append(lg)
        self.assertLess((torch.cat(steps, 1) - full).abs().max().item(), 1e-4)

    def test_gqa_head_mapping(self):
        from model.transformer import MiniCoderAttention
        a = MiniCoderAttention(self.cfg); k = torch.arange(2 * a.nkv).float().view(1, a.nkv, 2)[..., None].expand(1, a.nkv, 2, 3)
        ke = k[:, :, None].expand(1, a.nkv, a.rep, 2, 3).reshape(1, a.nh, 2, 3)
        self.assertTrue(torch.equal(ke, k.repeat_interleave(a.rep, dim=1)))

    def test_generate_and_length_guard(self):
        out = self.m.generate(torch.randint(0, self.cfg.vocab_size, (1, 5)), max_new_tokens=6, temperature=0)
        self.assertEqual(out.shape, (1, 11))
        with self.assertRaises(ValueError): self.m(torch.zeros(1, self.cfg.max_position_embeddings + 1, dtype=torch.long))


@unittest.skipUnless(HAS_TORCH, "torch not installed")
class TestTraining(unittest.TestCase):
    def test_grad_accum_equals_big_batch(self):
        from model.transformer import MiniCoder7B
        import torch.nn.functional as F
        cfg = load_config("config/model_tiny.yaml"); torch.manual_seed(1)
        m1, m2 = MiniCoder7B(cfg), MiniCoder7B(cfg); m2.load_state_dict(m1.state_dict())
        x = torch.randint(0, cfg.vocab_size, (4, 16)); y = torch.randint(0, cfg.vocab_size, (4, 16))
        F.cross_entropy(m1(x).reshape(-1, cfg.vocab_size), y.reshape(-1)).backward()
        for i in range(2):   # 2 micro-batches of 2, each loss / 2
            (F.cross_entropy(m2(x[2 * i:2 * i + 2]).reshape(-1, cfg.vocab_size), y[2 * i:2 * i + 2].reshape(-1)) / 2).backward()
        g = max((a.grad - b.grad).abs().max().item() for a, b in zip(m1.parameters(), m2.parameters()))
        self.assertLess(g, 1e-5)

    def test_smoke_end_to_end(self):
        from training.smoke import run_smoke_test
        self.assertTrue(run_smoke_test())


if __name__ == "__main__":
    unittest.main()
