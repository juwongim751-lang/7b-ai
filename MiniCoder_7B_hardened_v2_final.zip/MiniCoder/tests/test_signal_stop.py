import signal
import unittest
from unittest.mock import patch

from training.trainer import Trainer


class TestGracefulSignalStop(unittest.TestCase):
    def test_sigterm_requests_stop_and_restores_previous_handler(self):
        original = signal.getsignal(signal.SIGTERM)
        trainer = Trainer.__new__(Trainer)
        trainer._termination_signal = None
        called=[]
        def fake_impl():
            handler=signal.getsignal(signal.SIGTERM)
            handler(signal.SIGTERM,None)
            called.append(True)
            return "stopped"
        trainer._train_impl=fake_impl
        self.assertEqual(trainer.train(), "stopped")
        self.assertTrue(called)
        self.assertEqual(signal.getsignal(signal.SIGTERM), original)
        self.assertEqual(trainer._termination_signal, signal.SIGTERM)


if __name__ == "__main__": unittest.main()
