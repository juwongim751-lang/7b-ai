import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.local import LocalProvider


class TestLocalProvider(unittest.TestCase):
    def test_local_status_and_path_are_inspection_only(self):
        with tempfile.TemporaryDirectory() as d:
            info = SimpleNamespace(provider="local", gpu_available=False, gpu_name=None,
                                   vram_total_bytes=None, vram_free_bytes=None,
                                   cuda_runtime=None, torch_version="mock", cuda_device_count=0,
                                   system_ram_total_bytes=1024, system_ram_available_bytes=512,
                                   storage_path=d, storage_free_bytes=4096,
                                   local_training_process_possible=True)
            provider = LocalProvider(d)
            with patch("providers.local.detect_environment", return_value=info):
                result = provider.setup_environment()
            self.assertTrue(result["runtime_detected"])
            self.assertFalse(result["gpu"]["available"])
            self.assertFalse(result["capabilities"]["submit_cloud_job"])
            self.assertFalse(result["capabilities"]["persistent_storage_verified"])
            self.assertEqual(result["system"]["ram_total_bytes"], 1024)
            self.assertTrue(result["execution"]["training_process_possible"])
            self.assertEqual(provider.get_storage_path(), str(Path(d)/"checkpoints"))
            self.assertFalse((Path(d)/"checkpoints").exists())

    def test_worker_command_requires_single_local_worker(self):
        provider = LocalProvider()
        with patch("providers.local.shutil.which", return_value="/mock/torchrun"):
            command = provider.run_worker_command(0, 1, "127.0.0.1", 12345)
            self.assertIn("--nnodes=1", command)
            with self.assertRaises(NotImplementedError):
                provider.run_worker_command(0, 2, "127.0.0.1", 12345)
        with patch("providers.local.shutil.which", return_value=None):
            with self.assertRaises(NotImplementedError):
                provider.run_worker_command(0, 1, "127.0.0.1", 12345)


if __name__ == "__main__":
    unittest.main()
