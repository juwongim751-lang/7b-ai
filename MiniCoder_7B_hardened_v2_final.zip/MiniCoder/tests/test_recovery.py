import tempfile
import unittest
from pathlib import Path

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


@unittest.skipUnless(HAS_TORCH, "torch not installed")
class TestCheckpointRecovery(unittest.TestCase):
    def _saved(self, directory, metadata=None):
        from training.checkpoint import CheckpointManager
        model = torch.nn.Linear(3, 2)
        opt = torch.optim.AdamW(model.parameters())
        sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda _: 1.0)
        manager = CheckpointManager(directory, metadata=metadata or {})
        return Path(manager.save(model, opt, sched, 3, 0.75, 1, tokens_seen=240,
                                 metadata={"model_config":{"hidden_size":3,"use_bitnet":False},
                                           "tokenizer_config":{"algorithm":"byte_level_bpe","fingerprint":"abc"},
                                           "train_config":{"seed":123,"max_steps":10}}))

    def test_cross_directory_transfer_and_inventory(self):
        from training.recovery import list_valid_checkpoints, transfer_checkpoint
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / "source"; dest = Path(d) / "destination"; source.mkdir()
            checkpoint = self._saved(source)
            result = transfer_checkpoint(checkpoint, dest)
            self.assertEqual(result["integrity"], "verified")
            self.assertEqual(result["step"], 3)
            self.assertEqual(len(list_valid_checkpoints(dest)), 1)
            self.assertEqual(list_valid_checkpoints(dest)[0]["sha256"], result["sha256"])

    def test_tampered_or_incomplete_checkpoint_is_not_transferable(self):
        from training.recovery import list_valid_checkpoints, transfer_checkpoint
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / "source"; source.mkdir(); checkpoint = self._saved(source)
            with checkpoint.open("ab") as stream: stream.write(b"damage")
            self.assertEqual(list_valid_checkpoints(source), [])
            with self.assertRaises((IOError, OSError)): transfer_checkpoint(checkpoint, Path(d) / "dest")

    def test_missing_manifest_not_listed_as_complete(self):
        from training.recovery import list_valid_checkpoints
        with tempfile.TemporaryDirectory() as d:
            checkpoint = self._saved(d)
            checkpoint.with_suffix(checkpoint.suffix + ".manifest.json").unlink()
            self.assertEqual(list_valid_checkpoints(d), [])

    def test_checkpoint_v3_persists_recovery_configuration_and_seed(self):
        from training.checkpoint import CheckpointManager
        with tempfile.TemporaryDirectory() as d:
            path=self._saved(d)
            state=torch.load(path,map_location="cpu",weights_only=False)
            self.assertEqual(state["format_version"],3)
            self.assertEqual(state["tokens_seen"],240)
            self.assertEqual(state["random_seed"],123)
            self.assertEqual(state["model_config"]["hidden_size"],3)
            self.assertEqual(state["tokenizer_config"]["fingerprint"],"abc")
            self.assertEqual(state["training_config"]["max_steps"],10)
            self.assertIn("bitnet_config",state)

    def test_unknown_checkpoint_format_version_is_rejected(self):
        from training.checkpoint import CheckpointManager
        with tempfile.TemporaryDirectory() as d:
            path=self._saved(d)
            state=torch.load(path,map_location="cpu",weights_only=False)
            state["format_version"]=999
            torch.save(state,path)
            import hashlib
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            path.with_suffix(path.suffix+".sha256").write_text(f"{digest}  {path.name}\n",encoding="utf-8")
            manifest_path=path.with_suffix(path.suffix+".manifest.json")
            import json
            manifest=json.loads(manifest_path.read_text(encoding="utf-8")); manifest["sha256"]=digest
            manifest_path.write_text(json.dumps(manifest),encoding="utf-8")
            manager=CheckpointManager(d)
            model=torch.nn.Linear(3,2); opt=torch.optim.AdamW(model.parameters())
            sched=torch.optim.lr_scheduler.LambdaLR(opt,lambda _:1.0)
            with self.assertRaisesRegex(ValueError,"unsupported checkpoint format_version"):
                manager.load_latest(model,opt,sched)


if __name__ == "__main__": unittest.main()
