import unittest

from training.cost_guard import EstimatedCostGuard
from training.config import TrainConfig


class TestEstimatedCostGuard(unittest.TestCase):
    def test_paid_configuration_requires_explicit_approval(self):
        with self.assertRaises(PermissionError):
            EstimatedCostGuard(0.5, 1.0, confirmed=False)
    def test_budget_estimate_stops_before_next_step(self):
        clock=[100.0]
        guard=EstimatedCostGuard(1.0, 0.02, confirmed=True, reserve_seconds=60, clock=lambda:clock[0])
        self.assertFalse(guard.should_stop_before_next_step())
        clock[0]+=12*60
        self.assertTrue(guard.should_stop_before_next_step())
        self.assertFalse(guard.report()["hard_billing_cap"])
    def test_free_configuration_is_inert(self):
        guard=EstimatedCostGuard()
        self.assertFalse(guard.should_stop_before_next_step())
        self.assertFalse(guard.report()["active"])
    def test_train_config_requires_rate_budget_pair(self):
        with self.assertRaises(ValueError): TrainConfig(gpu_cost_rate_usd_per_hour=1.0)
        with self.assertRaises(ValueError): TrainConfig(max_budget_usd=-1)


if __name__ == "__main__": unittest.main()
