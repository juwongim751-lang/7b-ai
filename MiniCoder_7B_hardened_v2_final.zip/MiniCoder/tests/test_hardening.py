import json, tempfile, threading, unittest
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from controller.registry import WorkerRegistry
from controller.scheduler import GPUScheduler
from agent.tools import ToolRegistry
from agent.rag import RepositoryIndex,EmbeddingBackend
from workers.worker import WorkerAgent
class FakeEmb(EmbeddingBackend):
    name='fake-semantic'
    def encode(self,texts): return [[1.0,0.0] if 'database' in t.lower() or 'sql' in t.lower() else [0.0,1.0] for t in texts]
class Handler(BaseHTTPRequestHandler):
    calls=[]
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers.get('content-length','0')))); self.__class__.calls.append((self.path,body))
        if self.path.endswith('/register'): out={'worker_id':'server-issued-id','status':'registered'}
        else: out={'status':'alive'}
        self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(json.dumps(out).encode())
    def log_message(self,*args): pass
class TestHardening(unittest.TestCase):
    def test_worker_real_http_register_and_heartbeat(self):
        Handler.calls=[]; server=HTTPServer(('127.0.0.1',0),Handler); threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            w=WorkerAgent(f'http://127.0.0.1:{server.server_port}'); self.assertTrue(w.register()); self.assertEqual(w.worker_id,'server-issued-id'); self.assertTrue(w.send_heartbeat()); self.assertEqual([x[0] for x in Handler.calls],['/workers/register','/workers/heartbeat'])
        finally: server.shutdown(); server.server_close()
    def test_worker_requires_https_for_remote_controller_and_bounds_heartbeat_retries(self):
        with self.assertRaises(ValueError): WorkerAgent('http://controller.example')
        secure_worker=WorkerAgent('https://controller.example'); self.assertIsNotNone(secure_worker); secure_worker.stop()
        worker=WorkerAgent('http://127.0.0.1:8000'); worker.worker_id='mock-id'
        with patch.object(worker.stop_event,'wait',side_effect=[False]*5) as wait, \
             patch.object(worker,'send_heartbeat',return_value=False) as heartbeat:
            self.assertFalse(worker.run_heartbeat_loop(interval=1))
            self.assertEqual(heartbeat.call_count,5)
            self.assertEqual(wait.call_count,5)
        worker.stop()
    def test_scheduler_rejects_incompatible_vram_sum(self):
        r=WorkerRegistry(); base={'provider':'cloud-a','gpu_name':'T4','vram_total':16000,'vram_available':16000,'network_id':'net-a','runtime':'python','distributed_backend':'nccl','reachable':True}
        r.register(base); r.register({**base,'provider':'cloud-b','network_id':'net-b'}); self.assertEqual(GPUScheduler(r).decide_training_mode(20000)[0],'INDEPENDENT_TASKS')
        r.register({**base,'network_id':'net-a'}); self.assertEqual(GPUScheduler(r).decide_training_mode(20000)[0],'FSDP_DISTRIBUTED')
    def test_registry_issues_worker_ids_and_drops_unknown_secrets(self):
        registry=WorkerRegistry(); secret='private-token-do-not-store'
        worker_id=registry.register({'provider':'local','gpu_name':'CPU','vram_total':0,'vram_available':99,
                                     'reachable':'false','worker_id':'attacker-selected-id',
                                     'api_token':secret,'password':secret,'hostname':'safe-host'})
        result=registry.get_worker_status()[worker_id]
        self.assertNotEqual(worker_id,'attacker-selected-id')
        self.assertEqual(result['vram_available'],0)
        self.assertFalse(result['reachable'])
        self.assertEqual(result['capabilities'],{'hostname':'safe-host'})
        self.assertNotIn(secret,repr(registry.get_worker_status()))
        with self.assertRaises(ValueError):
            registry.register({'provider':'local','gpu_name':'CPU','vram_total':-1})
    def test_tools_no_shell_injection(self):
        with tempfile.TemporaryDirectory() as d:
            t=ToolRegistry(d); self.assertFalse(t.run_command('python -c "open(\'pwned\',\'w\').write(\'x\')"',approved=False).ok); self.assertFalse((Path(d)/'pwned').exists()); self.assertFalse(t.run_command(['sh','-c','echo bad']).ok)
    def test_true_semantic_backend_is_explicit(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'a.py').write_text('def sql_query():\n return database.fetch()\n'); (root/'b.py').write_text('def paint():\n return canvas.draw()\n'); idx=RepositoryIndex(root,embedding_backend=FakeEmb()); idx.index(); hits=idx.search('database lookup'); self.assertEqual(hits[0]['path'],'a.py'); self.assertEqual(hits[0]['search_mode'],'semantic+lexical')
if __name__=='__main__': unittest.main()
