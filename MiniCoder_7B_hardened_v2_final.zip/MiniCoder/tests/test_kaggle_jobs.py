import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.kaggle_jobs import KaggleKernelClient


class TestKaggleKernelClient(unittest.TestCase):
    def _kernel(self, root):
        (root / "minicoder.ipynb").write_text('{"cells":[],"metadata":{},"nbformat":4,"nbformat_minor":5}', encoding="utf-8")
        metadata={"id":"test-owner/minicoder-run","title":"MiniCoder smoke","code_file":"minicoder.ipynb",
                  "language":"python","kernel_type":"notebook","is_private":True,
                  "enable_gpu":True,"enable_internet":False,"dataset_sources":[]}
        return metadata

    def test_prepare_and_submit_require_explicit_quota_consent(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); metadata=self._kernel(root)
            client=KaggleKernelClient(executable="/mock/kaggle",env={})
            prepared=client.prepare_kernel_metadata(root,metadata)
            self.assertTrue(prepared["gpu_requested"])
            with patch("providers.kaggle_jobs.subprocess.run") as run:
                run.return_value=SimpleNamespace(returncode=0,stdout="submitted",stderr="")
                with self.assertRaises(PermissionError): client.submit(root,confirm_submit=False)
                self.assertEqual(run.call_count,0)
                result=client.submit(root,confirm_submit=True)
                self.assertTrue(result["submitted"])
                self.assertEqual(result["provider_acceptance"],"submitted_not_confirmed_running")
                args=run.call_args.args[0]
                self.assertIn("kernels",args); self.assertIn("push",args)
                self.assertFalse(run.call_args.kwargs["shell"])

    def test_invalid_metadata_path_and_kernel_slug_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); metadata=self._kernel(root)
            client=KaggleKernelClient(executable="/mock/kaggle")
            bad=dict(metadata,id="../../outside")
            with self.assertRaises(ValueError): client.prepare_kernel_metadata(root,bad)
            bad=dict(metadata,code_file="../minicoder.ipynb")
            with self.assertRaises(ValueError): client.prepare_kernel_metadata(root,bad)

    def test_status_and_output_download_use_official_command_shapes(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            def run(cmd,**kwargs):
                calls.append(cmd)
                if "output" in cmd:
                    Path(cmd[cmd.index("-p")+1],"checkpoint.pt").write_bytes(b"x")
                return SimpleNamespace(returncode=0,stdout="complete",stderr="")
            client=KaggleKernelClient(executable="/mock/kaggle")
            with patch("providers.kaggle_jobs.subprocess.run",side_effect=run):
                status=client.status("owner/kernel")
                output=client.download_output("owner/kernel",d)
            self.assertEqual(status["status_text"],"complete")
            self.assertEqual(Path(output["files"][0]).name,"checkpoint.pt")
            self.assertIn(["/mock/kaggle","kernels","status","owner/kernel"],calls)


if __name__ == "__main__": unittest.main()
