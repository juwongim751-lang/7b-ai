import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from dataset.public import load_public_hf_dataset
from dataset.registry import DatasetRegistry


class TestPublicDataset(unittest.TestCase):
    def test_public_dataset_streaming_records_provenance_and_disables_remote_code(self):
        rows = [{"content": "print(1)"}, {"content": "  "}, {"content": "return 2"}]
        calls = {}
        def fake_load_dataset(*args, **kwargs):
            calls["args"], calls["kwargs"] = args, kwargs
            return iter(rows)
        with tempfile.TemporaryDirectory() as d:
            output = Path(d) / "dataset.jsonl"
            with patch.dict("sys.modules", {"datasets": SimpleNamespace(load_dataset=fake_load_dataset)}):
                result = load_public_hf_dataset("owner/code-data", output, license_id="MIT",
                                                source_url="https://huggingface.co/datasets/owner/code-data",
                                                text_field="content", max_samples=2, revision="abc123")
            saved = [json.loads(line) for line in output.read_text(encoding="utf-8").splitlines()]
            metadata = json.loads(output.with_suffix(".jsonl.source.json").read_text(encoding="utf-8"))
        self.assertEqual(len(saved), 2)
        self.assertEqual(result["samples_written"], 2)
        self.assertFalse(calls["kwargs"]["trust_remote_code"])
        self.assertTrue(calls["kwargs"]["streaming"])
        self.assertFalse(metadata["credential_used"])
        self.assertEqual(metadata["license_verified_by"], "caller_attestation_not_automatically_verified")

    def test_unknown_license_and_non_https_source_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):
                load_public_hf_dataset("org/data", Path(d)/"out.jsonl", license_id="Unknown",
                                       source_url="https://example.com")
            with self.assertRaises(ValueError):
                load_public_hf_dataset("org/data", Path(d)/"out.jsonl", license_id="MIT",
                                       source_url="http://example.com")

    def test_local_registry_requires_license_and_records_metadata(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"mine.jsonl"; path.write_text('{"text":"hello"}\n', encoding="utf-8")
            registry=DatasetRegistry(Path(d)/"registry.json")
            with self.assertRaises(ValueError): registry.register("unknown", path, "UNKNOWN")
            entry=registry.register("my-data", path, "MIT", notes="User supplied")
            self.assertEqual(entry["license"], "MIT")
            self.assertEqual(registry.list()[0]["name"], "my-data")
            self.assertIn("caller_attestation", registry.list()[0]["license_verified_by"])


if __name__ == "__main__":
    unittest.main()
