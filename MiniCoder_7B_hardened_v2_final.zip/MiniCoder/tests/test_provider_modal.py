"""Offline tests for the inspection-only Modal provider adapter."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from providers.base import BaseProvider
from providers.modal import ModalProvider
class FakeCuda:
    def is_available(self):
        return True
    def device_count(self):
        return 1
    def get_device_name(self, index):
        return "Mock Modal GPU"
class TestModalProvider(unittest.TestCase):
    def test_implements_base_contract_and_detects_only_modal_runtime_markers(self):
        provider = ModalProvider(
            env={"MODAL_TASK_ID": "private-task-id", "OTHER": "ignored"},
            sdk_available=False,
            torch_module=None,
            nvidia_smi_path=None,
        )
        self.assertIsInstance(provider, BaseProvider)
        self.assertEqual(
            provider.detect_runtime(),
            {"detected": True, "indicators": {
                "task_id_environment_variable": True,
                "is_remote_environment_flag": False,
            }},
        )
        self.assertNotIn("private-task-id", repr(provider.detect_runtime()))
        self.assertTrue(
            ModalProvider(env={"MODAL_IS_REMOTE": "true"}, sdk_available=False).detect_runtime()["detected"]
        )
        self.assertFalse(
            ModalProvider(env={"MODAL_IS_REMOTE": "false", "MODAL_TASK_ID": " "}, sdk_available=False)
            .detect_runtime()["detected"]
        )
        self.assertFalse(ModalProvider(env={"MODAL_TOKEN_ID": "id"}, sdk_available=False).detect_runtime()["detected"])
        self.assertFalse(ModalProvider(env={"COLAB_GPU": "GPU"}, sdk_available=False).detect_runtime()["detected"])
    def test_sdk_detection_is_local_and_injectable(self):
        self.assertTrue(ModalProvider(env={}, sdk_available=True).inspect_runtime()["sdk"]["available_locally"])
        self.assertFalse(ModalProvider(env={}, sdk_available=False).inspect_runtime()["sdk"]["available_locally"])
        with patch("providers.modal.importlib.util.find_spec", return_value=object()) as find_spec:
            report = ModalProvider(env={}, torch_module=None, nvidia_smi_path=None).inspect_runtime()
        find_spec.assert_called_once_with("modal")
        self.assertTrue(report["sdk"]["available_locally"])
    def test_storage_paths_are_local_and_not_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            working = Path(tmp) / "work"
            working.mkdir()
            provider = ModalProvider(
                env={}, working_path=working, credential_file_path=None, sdk_available=False,
                torch_module=None, nvidia_smi_path=None,
            )
            report = provider.setup_environment()
            self.assertEqual(report["runtime_scope"], "local_process")
            self.assertEqual(report["paths"]["working"], {"path": str(working), "exists": True})
            self.assertEqual(
                report["paths"]["output"],
                {"path": str(working / "minicoder_output"), "exists": False},
            )
            self.assertEqual(provider.get_storage_path(), str(working / "minicoder_output"))
            self.assertFalse((working / "minicoder_output").exists())
            self.assertTrue(report["capabilities"]["write_local_working_directory"])
            self.assertFalse(report["capabilities"]["persistent_storage_verified"])
            self.assertEqual(report["capabilities"]["submit_cloud_job"], "unsupported")
    def test_credentials_report_presence_only_and_never_expose_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            config_file = Path(tmp) / "modal.toml"
            config_file.write_text('token_id = "file-secret-id"\ntoken_secret = "file-secret"\n', encoding="utf-8")
            env = {"MODAL_TOKEN_ID": "env-secret-id", "MODAL_TOKEN_SECRET": "env-secret-value"}
            report = ModalProvider(
                env=env, credential_file_path=config_file, sdk_available=False,
                torch_module=None, nvidia_smi_path=None,
            ).inspect_runtime()
            self.assertEqual(
                report["credentials"],
                {
                    "token_id_environment_variable_present": True,
                    "token_secret_environment_variable_present": True,
                    "environment_credentials_present": True,
                    "credential_file_present": True,
                },
            )
            serialized = repr(report)
            for secret in (*env.values(), "file-secret-id", "file-secret"):
                self.assertNotIn(secret, serialized)
        absent = ModalProvider(env={}, credential_file_path=None, sdk_available=False).inspect_runtime()
        self.assertFalse(absent["credentials"]["environment_credentials_present"])
        self.assertFalse(absent["credentials"]["credential_file_present"])
    def test_injected_torch_gpu_inspection_and_absent_nvidia_smi(self):
        provider = ModalProvider(
            env={}, sdk_available=False, torch_module=SimpleNamespace(cuda=FakeCuda()), nvidia_smi_path=None,
        )
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(gpu["torch"]["device_count"], 1)
        self.assertEqual(gpu["torch"]["devices"], [{"index": 0, "name": "Mock Modal GPU"}])
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})
    def test_missing_torch_and_nvidia_smi_are_reported_safely(self):
        provider = ModalProvider(env={}, sdk_available=False, torch_module=None, nvidia_smi_path=None)
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(
            gpu["torch"],
            {"available": False, "cuda_available": None, "device_count": None, "devices": []},
        )
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})
    @patch("providers.modal.subprocess.run")
    def test_nvidia_smi_is_queried_without_shell_and_parsed(self, run):
        run.return_value = SimpleNamespace(returncode=0, stdout="Mock GPU, 16000, 12000\n")
        provider = ModalProvider(
            env={}, sdk_available=False, torch_module=None, nvidia_smi_path="/mock/nvidia-smi",
        )
        result = provider.inspect_runtime()["gpu"]["nvidia_smi"]
        self.assertEqual(
            result,
            {
                "available": True,
                "query_succeeded": True,
                "devices": [{"name": "Mock GPU", "memory_total_mib": "16000", "memory_free_mib": "12000"}],
            },
        )
        args, kwargs = run.call_args
        self.assertEqual(args[0][0], "/mock/nvidia-smi")
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["timeout"], 3)
    def test_cost_bearing_job_operations_are_explicitly_unsupported(self):
        provider = ModalProvider(env={"MODAL_TASK_ID": "task"}, sdk_available=True)
        report = provider.inspect_runtime()
        self.assertEqual(report["capabilities"]["submit_cloud_job"], "unsupported")
        self.assertEqual(report["capabilities"]["execute_worker_command"], "unsupported")
        self.assertEqual(report["capabilities"]["generate_local_worker_command"], "unsupported")
        self.assertEqual(report["capabilities"]["access_remote_modal_account"], "unsupported")
        self.assertEqual(report["capabilities"]["inspect_cloud_credits_or_quota"], "unsupported")
        with self.assertRaises(NotImplementedError):
            provider.run_worker_command(0, 1, "127.0.0.1", 12345)
if __name__ == "__main__":
    unittest.main()
