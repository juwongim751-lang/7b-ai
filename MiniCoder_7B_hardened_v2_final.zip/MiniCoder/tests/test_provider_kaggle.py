"""Offline tests for the local-only Kaggle provider adapter."""
import shlex
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.kaggle import KaggleProvider


class FakeCuda:
    def is_available(self):
        return True

    def device_count(self):
        return 1

    def get_device_name(self, index):
        return "Mock Kaggle GPU"


class TestKaggleProvider(unittest.TestCase):
    def test_detection_uses_only_injected_kaggle_environment_markers(self):
        provider = KaggleProvider(
            env={"KAGGLE_KERNEL_RUN_TYPE": "Interactive", "OTHER": "set"},
            working_path="/not-present/working",
            input_path="/not-present/input",
            torch_module=None,
            nvidia_smi_path=None,
        )
        self.assertEqual(
            provider.detect_runtime(),
            {"detected": True, "indicators": {"kernel_run_type": True, "url_base": False}},
        )
        self.assertEqual(
            KaggleProvider(env={"KAGGLE_URL_BASE": "https://example.invalid"}).detect_runtime(),
            {"detected": True, "indicators": {"kernel_run_type": False, "url_base": True}},
        )
        self.assertFalse(KaggleProvider(env={"KAGGLE_KERNEL_RUN_TYPE": "  ", "KAGGLE_URL_BASE": ""}).detect_runtime()["detected"])
        self.assertFalse(KaggleProvider(env={"COLAB_GPU": "GPU"}).detect_runtime()["detected"])

    def test_reports_injected_input_working_and_checkpoint_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            input_path = root / "input"
            working_path = root / "working"
            input_path.mkdir()
            working_path.mkdir()
            provider = KaggleProvider(
                env={},
                input_path=input_path,
                working_path=working_path,
                credential_file_path=None,
                torch_module=None,
                nvidia_smi_path=None,
            )
            info = provider.inspect_runtime()
            self.assertEqual(info["paths"]["input"], {"path": str(input_path), "exists": True})
            self.assertEqual(info["paths"]["working"], {"path": str(working_path), "exists": True})
            self.assertEqual(
                info["paths"]["output"],
                {"path": str(working_path / "minicoder_output"), "exists": False},
            )
            self.assertEqual(provider.get_storage_path(), str(working_path / "minicoder_output"))
            self.assertFalse((working_path / "minicoder_output").exists())
            self.assertTrue(info["capabilities"]["write_local_working_directory"])
            self.assertFalse(info["capabilities"]["persistent_storage_verified"])

    def test_missing_directories_and_credential_file_are_not_inferred(self):
        with tempfile.TemporaryDirectory() as tmp:
            provider = KaggleProvider(
                env={},
                working_path=Path(tmp) / "missing-working",
                input_path=Path(tmp) / "missing-input",
                credential_file_path=Path(tmp) / "missing-credentials.json",
                torch_module=None,
                nvidia_smi_path=None,
            )
            info = provider.setup_environment()
            self.assertFalse(info["paths"]["input"]["exists"])
            self.assertFalse(info["paths"]["working"]["exists"])
            self.assertFalse(info["credentials"]["credential_file_present"])
            self.assertFalse(info["capabilities"]["submit_cloud_job"])
            self.assertFalse(info["capabilities"]["access_external_kaggle_session"])
            self.assertFalse(info["capabilities"]["execute_worker_command"])

    def test_reports_credential_presence_without_exposing_values_or_file_contents(self):
        with tempfile.TemporaryDirectory() as tmp:
            credential_file = Path(tmp) / "kaggle.json"
            credential_file.write_text('{"username":"private-user","key":"private-key"}', encoding="utf-8")
            provider = KaggleProvider(
                env={"KAGGLE_USERNAME": "env-user-secret", "KAGGLE_KEY": "env-key-secret"},
                credential_file_path=credential_file,
                torch_module=None,
                nvidia_smi_path=None,
            )
            info = provider.inspect_runtime()
            self.assertEqual(
                info["credentials"],
                {
                    "username_environment_variable_present": True,
                    "key_environment_variable_present": True,
                    "environment_credentials_present": True,
                    "credential_file_present": True,
                },
            )
            serialized = repr(info)
            for secret in ("env-user-secret", "env-key-secret", "private-user", "private-key"):
                self.assertNotIn(secret, serialized)

    def test_torch_gpu_inspection_works_with_injected_module(self):
        provider = KaggleProvider(
            env={"KAGGLE_KERNEL_RUN_TYPE": "Interactive"},
            torch_module=SimpleNamespace(cuda=FakeCuda()),
            nvidia_smi_path=None,
        )
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(gpu["torch"]["device_count"], 1)
        self.assertEqual(gpu["torch"]["devices"], [{"index": 0, "name": "Mock Kaggle GPU"}])
        self.assertFalse(gpu["nvidia_smi"]["available"])

    def test_missing_torch_and_nvidia_smi_are_reported_safely(self):
        provider = KaggleProvider(env={}, torch_module=None, nvidia_smi_path=None)
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(
            gpu["torch"],
            {"available": False, "cuda_available": None, "device_count": None, "devices": []},
        )
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})

    @patch("providers.kaggle.subprocess.run")
    def test_nvidia_smi_is_queried_without_shell_and_parsed(self, run):
        run.return_value = SimpleNamespace(returncode=0, stdout="Mock GPU, 16000, 12000\n")
        provider = KaggleProvider(env={}, torch_module=None, nvidia_smi_path="/mock/nvidia-smi")
        result = provider.inspect_runtime()["gpu"]["nvidia_smi"]
        self.assertEqual(
            result,
            {
                "available": True,
                "query_succeeded": True,
                "devices": [{"name": "Mock GPU", "memory_total_mib": "16000", "memory_free_mib": "12000"}],
            },
        )
        args, kwargs = run.call_args
        self.assertEqual(args[0][0], "/mock/nvidia-smi")
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["timeout"], 3)

    def test_worker_command_is_local_single_node_only_and_is_not_executed(self):
        provider = KaggleProvider(env={"KAGGLE_URL_BASE": "https://example.invalid"}, torch_module=None)
        with patch("providers.kaggle.shutil.which", return_value="/mock/torchrun"):
            command = provider.run_worker_command(0, 1, "127.0.0.1", 12345)
        args = shlex.split(command)
        self.assertEqual(args[0], "/mock/torchrun")
        self.assertIn("--nnodes=1", args)
        self.assertIn("--master_port=12345", args)
        self.assertEqual(args[-1], "training/trainer.py")
        self.assertIn("submit_cloud_job", provider.inspect_runtime()["capabilities"])
        self.assertFalse(provider.inspect_runtime()["capabilities"]["submit_cloud_job"])
        with patch("providers.kaggle.shutil.which", return_value="/mock/torchrun"):
            with self.assertRaises(NotImplementedError):
                provider.run_worker_command(0, 2, "127.0.0.1", 12345)

    def test_worker_command_rejects_missing_runtime_tool_and_invalid_port(self):
        with patch("providers.kaggle.shutil.which", return_value="/mock/torchrun"):
            with self.assertRaises(NotImplementedError):
                KaggleProvider(env={}, torch_module=None).run_worker_command(0, 1, "localhost", 12345)
        with patch("providers.kaggle.shutil.which", return_value=None):
            with self.assertRaises(NotImplementedError):
                KaggleProvider(env={"KAGGLE_KERNEL_RUN_TYPE": "Batch"}, torch_module=None).run_worker_command(
                    0, 1, "localhost", 12345
                )
        with patch("providers.kaggle.shutil.which", return_value="/mock/torchrun"):
            with self.assertRaises(ValueError):
                KaggleProvider(env={"KAGGLE_KERNEL_RUN_TYPE": "Batch"}, torch_module=None).run_worker_command(
                    0, 1, "localhost", 70000
                )
            with self.assertRaises(ValueError):
                KaggleProvider(env={"KAGGLE_KERNEL_RUN_TYPE": "Batch"}, torch_module=None).run_worker_command(
                    0, 1, "", 12345
                )


if __name__ == "__main__":
    unittest.main()
