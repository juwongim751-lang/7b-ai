import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from dashboard.backend.control import TrainingProcessManager


class TestDashboardControls(unittest.TestCase):
    def test_extra_args_allow_only_safe_training_controls(self):
        args = TrainingProcessManager._validated_extra_args(["--max-steps", "12", "--device", "cpu", "--resume"])
        self.assertEqual(args, ["--max-steps", "12", "--device", "cpu", "--resume"])
        for args in (["--config", "/tmp/evil.yaml"], ["--device", "bash"], ["--max-steps", "0"], [";", "touch /tmp/x"]):
            with self.subTest(args=args), self.assertRaises(ValueError):
                TrainingProcessManager._validated_extra_args(args)

    def _project(self, root):
        (root / "config").mkdir()
        (root / "config" / "model.yaml").write_text("preset: tiny\n", encoding="utf-8")

    def test_config_and_run_paths_cannot_escape_project(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); self._project(root); manager = TrainingProcessManager(root)
            with self.assertRaises(ValueError): manager.start(config="/etc/passwd", run_dir="runs/a")
            with self.assertRaises(ValueError): manager.start(config="config/model.yaml", run_dir="../outside")
            with self.assertRaises(ValueError): manager.start(config="config/model.yaml", run_dir="runs/a", extra_args=["--config", "x"])

    def test_paid_training_requires_rate_budget_and_confirmation(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); self._project(root); manager=TrainingProcessManager(root)
            with self.assertRaises(PermissionError):
                manager.start(config="config/model.yaml", run_dir="runs/paid", gpu_cost_rate_usd_per_hour=0.5,
                              max_budget_usd=1.0, confirm_potential_cost=False)
            with self.assertRaises(ValueError):
                manager.start(config="config/model.yaml", run_dir="runs/paid", gpu_cost_rate_usd_per_hour=0.5,
                              confirm_potential_cost=True)

    def test_restore_starts_local_resume_only_from_verified_checkpoint(self):
        import torch
        from training.checkpoint import CheckpointManager
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); self._project(root); manager=TrainingProcessManager(root)
            class FakeProcess:
                pid=12345
                def poll(self): return 0
            def fake_popen(cmd, **kwargs):
                instance=FakeProcess(); instance.command=cmd; calls.append(cmd); return instance
            calls=[]
            with patch("dashboard.backend.control.subprocess.Popen", side_effect=fake_popen):
                manager.start(config="config/model.yaml", run_dir="runs/demo")
                model=torch.nn.Linear(2,2); opt=torch.optim.AdamW(model.parameters())
                sched=torch.optim.lr_scheduler.LambdaLR(opt,lambda _:1.0)
                ckpt=root/"runs/demo/checkpoints"
                CheckpointManager(ckpt).save(model,opt,sched,2,0.5,0)
                result=manager.restore()
            self.assertEqual(result["restored_checkpoint"]["step"],2)
            self.assertIn("--resume",calls[-1])

    def test_model_export_uses_project_contained_paths_and_real_cli(self):
        import torch
        from training.checkpoint import CheckpointManager
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); self._project(root); manager=TrainingProcessManager(root)
            class FakeProcess:
                pid=7
                def poll(self): return 0
            with patch("dashboard.backend.control.subprocess.Popen",return_value=FakeProcess()):
                manager.start(config="config/model.yaml",run_dir="runs/export")
            model=torch.nn.Linear(2,2); opt=torch.optim.AdamW(model.parameters())
            sched=torch.optim.lr_scheduler.LambdaLR(opt,lambda _:1.0)
            CheckpointManager(root/"runs/export/checkpoints").save(model,opt,sched,1,1.0,0)
            with patch("dashboard.backend.control.subprocess.run") as run:
                run.return_value.returncode=0; run.return_value.stdout='ok'; run.return_value.stderr=''
                result=manager.export_model("runs/export/out",pack_bitnet=False)
            self.assertEqual(result["status"],"exported")
            args=run.call_args.args[0]
            self.assertIn("model.export_cli",args)
            self.assertTrue(args[-1].endswith("/runs/export/out"))

    def test_dashboard_status_endpoint_and_worker_registration(self):
        try:
            from fastapi.testclient import TestClient
            from dashboard.backend import main as dashboard_main
            app = dashboard_main.app
        except Exception as exc:
            self.skipTest(f"FastAPI test client unavailable: {exc}")
        with TestClient(app) as client:
            status = client.get("/status")
            self.assertEqual(status.status_code, 200)
            self.assertIn("status", status.json())
            with patch.dict("os.environ", {"MINICODER_DASHBOARD_TOKEN": "test-only-token"}):
                self.assertEqual(client.get("/providers").status_code, 401)
                provider_report = client.get("/providers", headers={"X-MiniCoder-Token": "test-only-token"})
                self.assertEqual(provider_report.status_code, 200)
                body=provider_report.json(); self.assertFalse(body["remote_actions_performed"])
                self.assertEqual(len(body["provider_reports"]),6)
                self.assertIn("runtime_resources",body["provider_reports"]["local"])
                self.assertEqual(client.post("/providers/plan",headers={"X-MiniCoder-Token":"test-only-token"},json={}).status_code,200)
                with patch.object(dashboard_main.kaggle_client, "submit",
                                  side_effect=PermissionError("explicit submit confirmation required")) as kaggle_submit:
                    kaggle_denied = client.post("/providers/kaggle/submit",
                                                headers={"X-MiniCoder-Token":"test-only-token"},
                                                json={"kernel_dir":"notebooks","confirm_submit":False})
                    self.assertEqual(kaggle_denied.status_code,409)
                    kaggle_submit.assert_called_once()
                    self.assertFalse(kaggle_submit.call_args.kwargs["confirm_submit"])
                denied=client.post("/workers/register",json={"provider":"mock","gpu_name":"CPU"})
                self.assertEqual(denied.status_code,401)
                accepted=client.post("/workers/register",headers={"X-MiniCoder-Token":"test-only-token"},
                                     json={"provider":"mock","gpu_name":"CPU","vram_total":0,
                                           "vram_available":0,"reachable":False})
                self.assertEqual(accepted.status_code,200)
                worker_id=accepted.json()["worker_id"]
                self.assertEqual(client.post("/workers/heartbeat",headers={"X-MiniCoder-Token":"test-only-token"},
                                             json={"worker_id":worker_id}).status_code,200)
            registered=client.post("/workers/register",json={"provider":"mock","gpu_name":"CPU","vram_total":0,
                                                              "vram_available":0,"runtime":"python",
                                                              "distributed_backend":"none","reachable":False})
            self.assertEqual(registered.status_code,200)
            worker_id=registered.json()["worker_id"]
            self.assertEqual(client.post("/workers/heartbeat",json={"worker_id":worker_id}).status_code,200)


if __name__ == "__main__": unittest.main()
