"""Real integration smoke test for the complete MiniCoder system.
Run: python -m tests.integration_test
Every result is produced by an executed assertion; no test is reported as passed without running.
"""
from __future__ import annotations
import json, tempfile, traceback
from pathlib import Path
import torch
from model.config import load_config
from model.transformer import MiniCoder7B
from dataset.tokenizer import MiniCoderTokenizer
from training.checkpoint import CheckpointManager
from controller.registry import WorkerRegistry
from controller.scheduler import GPUScheduler
from agent.rag import RepositoryIndex
from agent.memory import MemoryStore
from agent.tools import ToolRegistry
from agent.quality import CodeExecutor, SelfReviewer
from dashboard.backend.control import TrainingProcessManager

def run_full_test():
    results=[]
    def check(name, fn):
        try: fn(); results.append({'name':name,'status':'PASS'})
        except Exception as e: results.append({'name':name,'status':'FAIL','error':repr(e),'trace':traceback.format_exc()})
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); (root/'sample.py').write_text('def add(a,b):\n return a+b\n',encoding='utf-8')
        cfg=load_config('config/model_tiny.yaml'); model=MiniCoder7B(cfg)
        def tokenizer_check():
            tok=MiniCoderTokenizer(128); tok.train_from_iterator(['def add(a,b): return a+b\n']*3)
            assert tok.decode(tok.encode('한글 😀'))=='한글 😀'
        check('tokenizer_roundtrip', tokenizer_check)
        def model_check():
            x=torch.randint(0,cfg.vocab_size,(1,8)); out=model(x); assert out.shape==(1,8,cfg.vocab_size); out.float().mean().backward()
        check('model_forward_backward', model_check)
        def checkpoint_check():
            opt=torch.optim.AdamW(model.parameters(),lr=1e-3); sch=torch.optim.lr_scheduler.LambdaLR(opt,lambda _:1.0); c=CheckpointManager(root/'ckpt',metadata={'dataset_version':'integration'})
            p=c.save(model,opt,sch,1,1.0,0,metadata={'dataset_version':'integration'}); assert Path(p).exists(); assert c.load_latest(model,opt,sch,expected_metadata={'dataset_version':'integration'})['step']==1
        check('checkpoint_roundtrip', checkpoint_check)
        def rag_memory_tools():
            idx=RepositoryIndex(root); assert idx.index()['chunks']>=1 and idx.search('add')
            mem=MemoryStore(root/'memory.sqlite'); mem.put('project','decision','use safe tools'); assert mem.search('safe'); mem.close()
            tools=ToolRegistry(root); assert tools.read_file('sample.py').ok and not tools.write_file('x','bad').ok
        check('agent_rag_memory_tools', rag_memory_tools)
        def quality_and_control():
            assert CodeExecutor(root).run('python -c "print(1)"').ok; assert SelfReviewer(root).review()['passed']
            mgr=TrainingProcessManager(root); mgr.run_dir=root/'run'; mgr.run_dir.mkdir(); mgr.pause(); assert (mgr.run_dir/'PAUSE').exists(); mgr.resume(); assert not (mgr.run_dir/'PAUSE').exists(); mgr.checkpoint(); assert (mgr.run_dir/'CHECKPOINT').exists()
        check('execution_review_dashboard_controls', quality_and_control)
        def workers():
            reg=WorkerRegistry(); wid=reg.register({'provider':'local','gpu_name':'CPU','vram_total':0,'vram_available':0}); reg.update_heartbeat(wid); assert GPUScheduler(reg).decide_training_mode(1)[0]=='INDEPENDENT_TASKS'
        check('worker_scheduler', workers)
    passed=all(r['status']=='PASS' for r in results)
    report={'passed':passed,'executed':len(results),'results':results}
    print(json.dumps(report,ensure_ascii=False,indent=2)); return passed
if __name__=='__main__': raise SystemExit(0 if run_full_test() else 1)
