import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from model.config import load_config
from training.memory_estimator import estimate_inference_weight_bytes, estimate_training_memory_bytes
from training.plan import recommend_plan


class TestMemoryAndPlan(unittest.TestCase):
    def test_training_estimate_includes_fp32_optimizer_and_no_bitnet_credit(self):
        cfg = load_config("config/model_bitnet_tiny.yaml")
        estimate = estimate_training_memory_bytes(cfg, micro_batch_size=1, seq_len=64)
        self.assertEqual(estimate["parameter_gradient_optimizer_bytes"], cfg.calculate_parameters() * 16)
        self.assertFalse(estimate["bitnet_storage_credit_assumed"])
        self.assertGreater(estimate["estimated_training_bytes"], estimate["parameter_gradient_optimizer_bytes"])

    def test_inference_estimate_by_dtype(self):
        cfg = load_config("config/model_tiny_10m.yaml")
        fp16 = estimate_inference_weight_bytes(cfg, "fp16")
        fp32 = estimate_inference_weight_bytes(cfg, "fp32")
        self.assertEqual(fp32["bytes"], 2 * fp16["bytes"])
        self.assertFalse(fp16["kv_cache_included"])

    def test_auto_plan_uses_observed_memory_and_token_count(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "manifest.json").write_text('{"tokenization":{"total_tokens":8192}}', encoding="utf-8")
            env = SimpleNamespace(provider="local", gpu_available=True, gpu_name="Test GPU",
                                  vram_free_bytes=2 * 1024**3, system_ram_available_bytes=8 * 1024**3)
            result = recommend_plan("auto", d, seq_len=128, environment=env)
            self.assertIsNotNone(result["selected"])
            self.assertEqual(result["dataset_tokens"], 8192)
            self.assertEqual(result["recommended_training_config"]["max_steps_one_dataset_pass_estimate"], 8)
            self.assertFalse(result["automatic_downsize_performed"])

    def test_requested_7b_fallback_requires_user_confirmation(self):
        env = SimpleNamespace(provider="local", gpu_available=True, gpu_name="Small GPU",
                              vram_free_bytes=2 * 1024**3, system_ram_available_bytes=8 * 1024**3)
        result = recommend_plan("7b", "missing-data", seq_len=128, environment=env)
        self.assertTrue(result["requires_user_confirmation"])
        self.assertEqual(result["recommendation"], "smaller_preset_requires_user_confirmation")
        self.assertLess(result["selected"]["memory"]["parameters"], load_config("config/model_7b.yaml").calculate_parameters())

    def test_cpu_fallback_uses_available_ram_not_vram_claim(self):
        env = SimpleNamespace(provider="local", gpu_available=False, gpu_name=None,
                              vram_free_bytes=None, system_ram_available_bytes=4 * 1024**3)
        result = recommend_plan("auto", "missing-data", seq_len=128, environment=env)
        self.assertEqual(result["selected"]["capacity_kind"], "available_system_ram")
        self.assertIsNone(result["free_vram_bytes"])

    def test_measured_auto_batch_probe_does_not_update_model_weights(self):
        import torch
        from model.config import MiniCoderConfig
        from model.transformer import MiniCoder7B
        from training.auto_tune import probe_auto_batch_size
        cfg=MiniCoderConfig(vocab_size=16,hidden_size=16,num_layers=1,num_heads=2,num_kv_heads=1,
                            intermediate_size=24,max_position_embeddings=8,tie_word_embeddings=False)
        model=MiniCoder7B(cfg)
        before=[p.detach().clone() for p in model.parameters()]
        data=[(torch.randint(0,16,(8,)),torch.randint(0,16,(8,))) for _ in range(4)]
        result=probe_auto_batch_size(model,data,micro_batch_size=1,grad_accum=2,seq_len=8,
                                     max_micro_batch_size=2,steps=1,device=torch.device('cpu'))
        self.assertIsNotNone(result["recommendation"])
        self.assertFalse(result["model_weights_updated_during_probe"])
        self.assertTrue(all(torch.equal(a,b) for a,b in zip(before,model.parameters())))


if __name__ == "__main__":
    unittest.main()
