import tempfile
import unittest

try:
    import torch
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


@unittest.skipUnless(HAS_TORCH, "torch not installed")
class TestBitNet(unittest.TestCase):
    def test_ternary_absmean_and_ste_gradient(self):
        from model.quantization import quantize_ternary_absmean
        w = torch.tensor([[-2.0, -0.3, 0.0, 0.6, 2.5]], requires_grad=True)
        q = quantize_ternary_absmean(w, straight_through=False)
        self.assertTrue(set(q.flatten().tolist()).issubset({-1.0, 0.0, 1.0}))
        q_ste = quantize_ternary_absmean(w)
        q_ste.square().sum().backward()
        self.assertIsNotNone(w.grad)
        self.assertTrue(torch.isfinite(w.grad).all())

    def test_activation_int8_zero_and_gradients(self):
        from model.quantization import quantize_activation_symmetric
        x = torch.tensor([[0.0, 0.0, 0.0], [-1.0, 0.31, 0.9]], requires_grad=True)
        y = quantize_activation_symmetric(x, bits=8)
        self.assertTrue(torch.isfinite(y).all())
        self.assertEqual(y[0].abs().max().item(), 0.0)
        y.sum().backward()
        self.assertTrue(torch.isfinite(x.grad).all())

    def test_bitlinear_forward_backward(self):
        from model.bitlinear import BitLinear
        layer = BitLinear(8, 4)
        x = torch.randn(3, 5, 8, requires_grad=True)
        y = layer(x)
        self.assertEqual(tuple(y.shape), (3, 5, 4))
        y.square().mean().backward()
        self.assertTrue(torch.isfinite(layer.weight.grad).all())
        self.assertTrue(torch.isfinite(x.grad).all())

    def test_bitnet_tiny_transformer_and_parameter_count(self):
        from model.config import MiniCoderConfig, load_config
        from model.transformer import MiniCoder7B
        cfg = load_config("config/model_bitnet_tiny.yaml")
        model = MiniCoder7B(cfg)
        x = torch.randint(0, cfg.vocab_size, (2, 12))
        logits = model(x)
        self.assertEqual(tuple(logits.shape), (2, 12, cfg.vocab_size))
        loss = F.cross_entropy(logits.reshape(-1, cfg.vocab_size), x.reshape(-1))
        loss.backward()
        self.assertTrue(all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()))
        self.assertEqual(model.num_parameters(), cfg.calculate_parameters())
        self.assertTrue(cfg.use_bitnet)

    def test_overfit_short_fixed_batch(self):
        """Tiny synthetic objective should improve; not a language quality claim."""
        from model.config import MiniCoderConfig
        from model.transformer import MiniCoder7B
        torch.manual_seed(12)
        cfg = MiniCoderConfig(vocab_size=16, hidden_size=16, num_layers=1, num_heads=2,
                              num_kv_heads=1, intermediate_size=24, max_position_embeddings=8,
                              tie_word_embeddings=False, precision="fp32", use_bitnet=True)
        model = MiniCoder7B(cfg)
        opt = torch.optim.AdamW(model.parameters(), lr=0.01)
        x = torch.tensor([[1, 2, 3, 1, 2, 3, 1], [4, 5, 6, 4, 5, 6, 4]])
        y = torch.tensor([[2, 3, 1, 2, 3, 1, 2], [5, 6, 4, 5, 6, 4, 5]])
        with torch.no_grad():
            initial = F.cross_entropy(model(x).reshape(-1, cfg.vocab_size), y.reshape(-1)).item()
        for _ in range(35):
            opt.zero_grad(set_to_none=True)
            loss = F.cross_entropy(model(x).reshape(-1, cfg.vocab_size), y.reshape(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        with torch.no_grad():
            final = F.cross_entropy(model(x).reshape(-1, cfg.vocab_size), y.reshape(-1)).item()
        self.assertTrue(torch.isfinite(torch.tensor(final)))
        self.assertLess(final, initial)

    def test_checkpoint_roundtrip_preserves_outputs(self):
        from model.config import MiniCoderConfig
        from model.transformer import MiniCoder7B
        from training.checkpoint import CheckpointManager
        cfg = MiniCoderConfig(vocab_size=16, hidden_size=16, num_layers=1, num_heads=2,
                              num_kv_heads=1, intermediate_size=24, max_position_embeddings=8,
                              tie_word_embeddings=False, use_bitnet=True)
        torch.manual_seed(2)
        first = MiniCoder7B(cfg).eval()
        opt = torch.optim.AdamW(first.parameters(), lr=1e-3)
        sch = torch.optim.lr_scheduler.LambdaLR(opt, lambda _: 1.0)
        sample = torch.tensor([[1, 2, 3, 4]])
        expected = first(sample).detach()
        with tempfile.TemporaryDirectory() as d:
            manager = CheckpointManager(d, keep=2)
            manager.save(first, opt, sch, 1, 1.0, 0)
            second = MiniCoder7B(cfg).eval()
            opt2 = torch.optim.AdamW(second.parameters(), lr=1e-3)
            sch2 = torch.optim.lr_scheduler.LambdaLR(opt2, lambda _: 1.0)
            state = manager.load_latest(second, opt2, sch2)
            actual = second(sample).detach()
        self.assertEqual(state["step"], 1)
        self.assertTrue(torch.equal(expected, actual))

    def test_five_ternary_values_pack_to_one_byte(self):
        from model.bitpack import pack_ternary_5, unpack_ternary_5
        ternary = torch.tensor([[-1, 0, 1, 1, -1, 0, 1, -1]], dtype=torch.int8)
        packed, shape = pack_ternary_5(ternary)
        restored = unpack_ternary_5(packed, shape, dtype=torch.int8)
        self.assertEqual(packed.dtype, torch.uint8)
        self.assertEqual(packed.numel(), 2)
        self.assertTrue(torch.equal(ternary, restored))

    def test_packed_bitnet_export_load_preserves_forward_and_is_compact(self):
        import json
        from pathlib import Path
        from model.config import load_config
        from model.transformer import MiniCoder7B
        from model.export import ModelExporter
        from model.load_export import load_exported_model
        cfg = load_config("config/model_bitnet_tiny.yaml")
        torch.manual_seed(31)
        model = MiniCoder7B(cfg).eval()
        sample = torch.randint(0, cfg.vocab_size, (1, 8))
        with torch.no_grad(): expected = model(sample)
        with tempfile.TemporaryDirectory() as d:
            path = ModelExporter(model, cfg).export(d, prefer_safetensors=False, pack_bitnet=True)
            loaded, loaded_cfg, manifest = load_exported_model(path)
            with torch.no_grad(): actual = loaded(sample)
            details = json.loads((Path(path) / "weights_manifest.json").read_text(encoding="utf-8"))
            self.assertTrue(loaded_cfg.use_bitnet)
            self.assertTrue(details["packed_ternary"])
            self.assertEqual(details["packed_weight_bits_per_ternary_weight"], 1.6)
            self.assertGreater(details["packed_layers"], 0)
            self.assertTrue(torch.allclose(expected, actual, atol=1e-6, rtol=1e-6))
            self.assertFalse(manifest["packed_ternary"] is False)


if __name__ == "__main__":
    unittest.main()
