import tempfile, unittest
from pathlib import Path
from agent.rag import RepositoryIndex
from agent.memory import MemoryStore
from agent.tools import ToolRegistry
from agent.quality import CodeExecutor, TestEngine, SelfReviewer
from agent.planner import PlanningEngine
from agent.providers import create_provider, ProviderError

class TestPhase7To10(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        (self.root/'sample.py').write_text('import os\ndef add(a, b):\n    return a + b\n',encoding='utf-8')
    def tearDown(self): self.tmp.cleanup()
    def test_rag_index_search_and_incremental(self):
        idx=RepositoryIndex(self.root); first=idx.index(); self.assertEqual(first['reindexed'],1)
        hits=idx.search('add function'); self.assertTrue(hits); self.assertEqual(hits[0]['path'],'sample.py')
        second=idx.index(); self.assertEqual(second['reindexed'],0)
        (self.root/'sample.py').write_text('def multiply(a,b): return a*b\n',encoding='utf-8')
        self.assertEqual(idx.index()['reindexed'],1)
    def test_memory_redacts_and_scopes(self):
        db=MemoryStore(self.root/'memory.sqlite'); db.put('project','decision','api_key=SECRET use sqlite',tags=['decision'])
        found=db.search('sqlite'); self.assertEqual(found[0]['value'],'api_key=[REDACTED] use sqlite'); self.assertIsNone(db.get('global','decision')); db.close()
    def test_tools_require_approval(self):
        t=ToolRegistry(self.root); self.assertFalse(t.write_file('x.txt','bad').ok); self.assertTrue(t.write_file('x.txt','ok',approved=True).ok); self.assertEqual(t.read_file('x.txt').output,'ok'); self.assertFalse(t.run_command('rm -rf x',approved=False).ok)
    def test_execution_testing_review(self):
        # Process creation on cold/contended CI hosts can exceed 5 seconds;
        # keep the success-path timeout generous and test deadline behavior separately.
        ex=CodeExecutor(self.root,timeout=20); self.assertTrue(ex.run([__import__('sys').executable, '-c', 'print(1)']).ok)
        result=TestEngine(self.root).run([f'python -m compileall -q .']); self.assertTrue(result['passed']); self.assertTrue(SelfReviewer(self.root).review()['passed'])

    def test_code_executor_reports_a_real_timeout(self):
        import sys
        result=CodeExecutor(self.root,timeout=0.2).run([sys.executable, '-c', 'import time; time.sleep(2)'])
        self.assertFalse(result.ok)
        self.assertTrue(result.timed_out)
    def test_planner_and_provider_registry(self):
        plan=PlanningEngine(self.root).plan('find add implementation'); self.assertTrue(plan['steps']); self.assertGreater(plan['context_chars'],0)
        p=create_provider('ollama','test'); self.assertEqual(p.name,'ollama')
        with self.assertRaises(ProviderError): create_provider('minicoder','local').chat([])
if __name__=='__main__': unittest.main()
