"""Offline tests for the local-only Lightning AI Studio provider adapter."""
import shlex
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.lightning import LightningProvider


class FakeCuda:
    def is_available(self):
        return True

    def device_count(self):
        return 1

    def get_device_name(self, index):
        return "Mock Lightning GPU"


class TestLightningProvider(unittest.TestCase):
    def test_detection_uses_injected_environment_and_studio_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            studio = Path(tmp) / "studio"
            provider = LightningProvider(env={"LIGHTNING_STUDIO": "private-studio-id"}, studio_path=studio)
            self.assertEqual(
                provider.detect_runtime(),
                {
                    "detected": True,
                    "indicators": {
                        "lightning_studio_environment_variable": True,
                        "lightning_cloud_project_id_environment_variable": False,
                        "studio_directory_exists": False,
                    },
                },
            )
            self.assertNotIn("private-studio-id", repr(provider.detect_runtime()))
            self.assertTrue(
                LightningProvider(
                    env={"LIGHTNING_CLOUD_PROJECT_ID": "project-id"}, studio_path=studio
                ).detect_runtime()["detected"]
            )
            studio.mkdir()
            self.assertTrue(LightningProvider(env={}, studio_path=studio).detect_runtime()["detected"])
            self.assertFalse(
                LightningProvider(env={"LIGHTNING_STUDIO": "  ", "LIGHTNING_CLOUD_PROJECT_ID": ""},
                                  studio_path=Path(tmp) / "missing").detect_runtime()["detected"]
            )
            self.assertFalse(
                LightningProvider(env={"COLAB_GPU": "GPU"}, studio_path=Path(tmp) / "missing")
                .detect_runtime()["detected"]
            )

    def test_storage_paths_are_local_and_are_not_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            studio = root / "studio"
            studio.mkdir()
            work = root / "work"
            provider = LightningProvider(env={}, studio_path=studio, working_path=work,
                                         torch_module=None, nvidia_smi_path=None)
            info = provider.setup_environment()
            self.assertEqual(info["paths"]["studio"], {"path": str(studio), "exists": True})
            self.assertEqual(info["paths"]["working"], {"path": str(work), "exists": False})
            self.assertEqual(info["paths"]["output"], {
                "path": str(work / "minicoder_output"), "exists": False
            })
            self.assertEqual(provider.get_storage_path(), str(work / "minicoder_output"))
            self.assertFalse(work.exists())
            self.assertFalse(info["capabilities"]["submit_cloud_job"] != "unsupported")
            self.assertEqual(info["capabilities"]["access_remote_studio_or_account"], "unsupported")
            self.assertEqual(info["capabilities"]["inspect_cloud_credits_or_quota"], "unsupported")
            self.assertFalse(info["capabilities"]["persistent_storage_verified"])

    def test_credential_status_is_boolean_only_and_does_not_expose_value(self):
        secret_value = "never-print-this-api-key"
        provider = LightningProvider(
            env={"LIGHTNING_CLOUD_API_KEY": secret_value},
            studio_path="/not-present",
            torch_module=None,
            nvidia_smi_path=None,
        )
        info = provider.inspect_runtime()
        self.assertEqual(info["credentials"], {"api_key_environment_variable_present": True})
        self.assertNotIn(secret_value, repr(info))
        self.assertEqual(
            LightningProvider(env={}, studio_path="/not-present", torch_module=None,
                              nvidia_smi_path=None).inspect_runtime()["credentials"],
            {"api_key_environment_variable_present": False},
        )

    def test_injected_torch_gpu_inspection(self):
        provider = LightningProvider(
            env={"LIGHTNING_STUDIO": "1"},
            studio_path="/not-present",
            torch_module=SimpleNamespace(cuda=FakeCuda()),
            nvidia_smi_path=None,
        )
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(gpu["torch"]["device_count"], 1)
        self.assertEqual(gpu["torch"]["devices"], [{"index": 0, "name": "Mock Lightning GPU"}])
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})

    def test_absent_torch_and_nvidia_smi_are_safe(self):
        provider = LightningProvider(env={}, studio_path="/not-present", torch_module=None,
                                     nvidia_smi_path=None)
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(gpu["torch"], {
            "available": False, "cuda_available": None, "device_count": None, "devices": []
        })
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})

    def test_nvidia_smi_is_queried_without_shell_and_parsed(self):
        with patch("providers.lightning.subprocess.run") as run:
            run.return_value = SimpleNamespace(returncode=0, stdout="Mock GPU, 16000, 12000\n")
            provider = LightningProvider(env={}, studio_path="/not-present", torch_module=None,
                                         nvidia_smi_path="/mock/nvidia-smi")
            result = provider.inspect_runtime()["gpu"]["nvidia_smi"]
        self.assertEqual(result, {
            "available": True,
            "query_succeeded": True,
            "devices": [{"name": "Mock GPU", "memory_total_mib": "16000", "memory_free_mib": "12000"}],
        })
        args, kwargs = run.call_args
        self.assertEqual(args[0][0], "/mock/nvidia-smi")
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["timeout"], 3)

    def test_worker_command_is_generated_only_for_local_single_worker(self):
        provider = LightningProvider(env={"LIGHTNING_STUDIO": "1"}, studio_path="/not-present",
                                     torch_module=None)
        with patch("providers.lightning.shutil.which", return_value="/mock/torchrun"):
            command = provider.run_worker_command(0, 1, "127.0.0.1", 12345)
        args = shlex.split(command)
        self.assertEqual(args[0], "/mock/torchrun")
        self.assertIn("--nnodes=1", args)
        self.assertIn("--master_port=12345", args)
        self.assertEqual(args[-1], "training/trainer.py")
        self.assertEqual(provider.inspect_runtime()["capabilities"]["execute_worker_command"], "unsupported")
        with patch("providers.lightning.shutil.which", return_value="/mock/torchrun"):
            with self.assertRaises(NotImplementedError):
                provider.run_worker_command(0, 2, "127.0.0.1", 12345)

    def test_worker_command_rejects_missing_runtime_tool_and_invalid_arguments(self):
        provider = LightningProvider(env={}, studio_path="/not-present", torch_module=None)
        with patch("providers.lightning.shutil.which", return_value="/mock/torchrun"):
            with self.assertRaises(NotImplementedError):
                provider.run_worker_command(0, 1, "localhost", 12345)
        detected = LightningProvider(env={"LIGHTNING_STUDIO": "1"}, studio_path="/not-present",
                                     torch_module=None)
        with patch("providers.lightning.shutil.which", return_value=None):
            with self.assertRaises(NotImplementedError):
                detected.run_worker_command(0, 1, "localhost", 12345)
        with patch("providers.lightning.shutil.which", return_value="/mock/torchrun"):
            with self.assertRaises(ValueError):
                detected.run_worker_command(0, 1, "localhost", 70000)
            with self.assertRaises(ValueError):
                detected.run_worker_command(0, 1, "", 12345)


if __name__ == "__main__":
    unittest.main()
