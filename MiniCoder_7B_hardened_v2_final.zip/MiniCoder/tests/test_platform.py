import hashlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.credentials import credential_status
from providers.detector import detect_environment
from providers.storage import DirectoryStorage, HuggingFaceHubStorage, modal_volume_storage


class TestPlatformUtilities(unittest.TestCase):
    def test_provider_detection_does_not_infer_gpu_from_environment(self):
        fake_torch = SimpleNamespace(__version__="x", version=SimpleNamespace(cuda=None),
                                     cuda=SimpleNamespace(is_available=lambda: False))
        info = detect_environment({"COLAB_RELEASE_TAG": "release"}, torch_module=fake_torch)
        self.assertEqual(info.provider, "colab")
        self.assertFalse(info.gpu_available)
        self.assertEqual(info.quota_visibility, "not_available_locally")
        self.assertFalse(info.remote_job_submission)

    def test_gpu_facts_require_active_runtime(self):
        fake_cuda = SimpleNamespace(is_available=lambda: True, current_device=lambda: 0,
                                     get_device_name=lambda _: "Mock GPU", mem_get_info=lambda _: (8, 16))
        fake_torch = SimpleNamespace(__version__="x", version=SimpleNamespace(cuda="mock"), cuda=fake_cuda)
        info = detect_environment({"KAGGLE_KERNEL_RUN_TYPE": "Interactive"}, torch_module=fake_torch)
        self.assertEqual(info.provider, "kaggle")
        self.assertEqual(info.gpu_name, "Mock GPU")
        self.assertEqual(info.vram_total_bytes, 16)

    def test_credentials_are_presence_only(self):
        status = credential_status("modal", {"MODAL_TOKEN_ID": "secret-id", "MODAL_TOKEN_SECRET": "secret-value"})
        self.assertTrue(status["configured"])
        self.assertEqual(status["environment_keys_present"], ["MODAL_TOKEN_ID", "MODAL_TOKEN_SECRET"])
        self.assertNotIn("secret-value", repr(status))
        self.assertFalse(status["secret_values_exposed"])

    def test_directory_storage_atomic_copy_checksum_and_traversal_guard(self):
        with tempfile.TemporaryDirectory() as d:
            root, source, restored = Path(d)/"store", Path(d)/"input.bin", Path(d)/"restored.bin"
            root.mkdir(); source.write_bytes(b"portable-checkpoint")
            storage = DirectoryStorage(root, max_bytes=1024, name="test")
            saved = storage.save("runs/checkpoint.bin", source)
            expected = hashlib.sha256(source.read_bytes()).hexdigest()
            self.assertEqual(saved["sha256"], expected)
            result = storage.restore("runs/checkpoint.bin", restored, expected)
            self.assertEqual(restored.read_bytes(), source.read_bytes())
            self.assertEqual(result["integrity"], "verified")
            for bad in ("../escape", "/absolute", "a/../../escape"):
                with self.subTest(path=bad), self.assertRaises(ValueError):
                    storage.save(bad, source)
            with self.assertRaises(IOError):
                storage.restore("runs/checkpoint.bin", restored, "0" * 64)

    def test_huggingface_remote_storage_is_gated_and_mocked(self):
        calls = []
        class FakeApi:
            def __init__(self, token):
                calls.append(("init", token))
            def create_repo(self, **kwargs):
                calls.append(("create", kwargs))
            def upload_file(self, **kwargs):
                calls.append(("upload", kwargs))
                return SimpleNamespace(oid="mock-commit")
        with tempfile.TemporaryDirectory() as d:
            source, restored = Path(d)/"checkpoint.bin", Path(d)/"restored.bin"
            source.write_bytes(b"mocked checkpoint")
            store = HuggingFaceHubStorage("owner/private-checkpoints")
            with patch.dict(os.environ, {"HF_TOKEN":"test-secret"}), patch.dict(sys.modules, {
                "huggingface_hub": SimpleNamespace(HfApi=FakeApi, hf_hub_download=lambda **_: str(source))
            }):
                with self.assertRaises(PermissionError):
                    store.save("run/checkpoint.bin", source)
                self.assertEqual(calls, [])
                saved = store.save("run/checkpoint.bin", source, confirm_upload=True)
                self.assertEqual(saved["visibility"], "private_requested")
                self.assertEqual(saved["revision"], "mock-commit")
                self.assertNotIn("test-secret", repr(saved))
                with self.assertRaises(PermissionError):
                    store.restore("run/checkpoint.bin", restored)
                restored_info = store.restore("run/checkpoint.bin", restored,
                                              expected_sha256=saved["sha256"], confirm_download=True)
                self.assertEqual(restored_info["integrity"], "verified")
                self.assertEqual(restored.read_bytes(), source.read_bytes())
                self.assertIn(("create", {"repo_id":"owner/private-checkpoints", "repo_type":"dataset",
                                          "private":True, "exist_ok":True}), calls)
        with tempfile.TemporaryDirectory() as d:
            modal = modal_volume_storage(d)
            self.assertEqual(modal.name, "modal_volume_mounted_directory")

    def test_notebooks_are_valid_sequential_notebook_documents(self):
        for name in ("minicoder_colab.ipynb", "minicoder_kaggle.ipynb"):
            with self.subTest(notebook=name):
                doc = json.loads((Path("notebooks")/name).read_text(encoding="utf-8"))
                self.assertEqual(doc["nbformat"], 4)
                self.assertGreaterEqual(len(doc["cells"]), 5)
                self.assertTrue(all(cell["cell_type"] in {"markdown", "code"} for cell in doc["cells"]))

    def test_model_scale_configs_match_declared_bands(self):
        from model.config import load_config
        ranges = {"model_tiny_10m.yaml": (10_000_000, 30_000_000),
                  "model_100m.yaml": (50_000_000, 150_000_000),
                  "model_300m.yaml": (200_000_000, 400_000_000),
                  "model_1b.yaml": (700_000_000, 1_300_000_000),
                  "model_3b.yaml": (2_000_000_000, 3_400_000_000),
                  "model_7b.yaml": (7_000_000_000, 7_500_000_000)}
        for filename, (low, high) in ranges.items():
            with self.subTest(config=filename):
                count = load_config(f"config/{filename}").calculate_parameters()
                self.assertGreaterEqual(count, low)
                self.assertLessEqual(count, high)


if __name__ == "__main__":
    unittest.main()
