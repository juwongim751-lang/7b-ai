import unittest
from types import SimpleNamespace

from providers.scheduler import ProviderScheduler


class FakeRegistry:
    def __init__(self, provider, resources, detected=True):
        self.provider=provider; self.resources=resources; self.detected=detected
    def inspect_all(self):
        row={"runtime_detected":self.detected, "runtime_resources":self.resources}
        return {"current_process":{"provider":self.provider},"provider_reports":{self.provider:row}}


class TestProviderScheduler(unittest.TestCase):
    def _resources(self, gpu=True, vram=8, ram=16, disk=100):
        return {"gpu_available":gpu,"gpu_name":"Mock GPU" if gpu else None,
                "vram_free_bytes":vram,"system_ram_available_bytes":ram,
                "storage_free_bytes":disk,"session_limit_seconds":None,
                "expected_duration_seconds":None}
    def test_selects_only_current_compatible_gpu(self):
        result=ProviderScheduler(FakeRegistry("local",self._resources())).plan(4,8,50)
        self.assertEqual(result["selected"]["provider"],"local")
        self.assertFalse(result["machine_pooling"])
        self.assertFalse(result["remote_actions_performed"])
    def test_rejects_insufficient_memory_or_no_cuda(self):
        for resources,req in [(self._resources(vram=1),(2,0,0)),(self._resources(gpu=False),(0,0,0))]:
            result=ProviderScheduler(FakeRegistry("kaggle",resources)).plan(*req)
            self.assertIsNone(result["selected"])
    def test_paid_provider_defaults_off_and_requires_cost_details(self):
        registry=FakeRegistry("modal",self._resources())
        denied=ProviderScheduler(registry).plan(allow_paid=False)
        self.assertIsNone(denied["selected"])
        approved=ProviderScheduler(registry).plan(allow_paid=True,max_budget_usd=2,
                                                  estimated_gpu_rate_usd_per_hour=0.5)
        self.assertIsNotNone(approved["selected"])
        self.assertEqual(approved["estimated_cost"]["estimated_gpu_seconds"],14400)
    def test_manual_notebooks_are_reported_not_submitted_and_zerogpu_rejected(self):
        result=ProviderScheduler(FakeRegistry("huggingface_zerogpu",self._resources())).plan()
        self.assertIsNone(result["selected"])
        self.assertEqual({x["provider"] for x in result["manual_notebook_options"]},{"kaggle","colab"})
        self.assertTrue(all(x["remote_submission_api"] is False for x in result["manual_notebook_options"]))


if __name__ == "__main__": unittest.main()
