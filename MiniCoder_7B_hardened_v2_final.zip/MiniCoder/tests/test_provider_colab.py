"""Offline tests for the local-only Colab provider adapter."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.colab import ColabProvider


class FakeCuda:
    def is_available(self):
        return True

    def device_count(self):
        return 1

    def get_device_name(self, index):
        return "Mock GPU"


class TestColabProvider(unittest.TestCase):
    def test_detection_uses_injected_environment_and_content_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            content = Path(tmp) / "content"
            provider = ColabProvider(env={"COLAB_RELEASE_TAG": "release"}, content_path=content)
            self.assertEqual(
                provider.detect_runtime(),
                {
                    "detected": True,
                    "indicators": {
                        "colab_release_tag": True,
                        "colab_gpu": False,
                        "content_directory": False,
                    },
                },
            )
            content.mkdir()
            self.assertTrue(provider.detect_runtime()["indicators"]["content_directory"])

    def test_empty_environment_and_missing_content_are_not_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            provider = ColabProvider(env={"COLAB_GPU": "  ", "COLAB_RELEASE_TAG": ""}, content_path=Path(tmp) / "missing")
            self.assertFalse(provider.detect_runtime()["detected"])

    def test_inspects_torch_cuda_without_importing_real_torch(self):
        provider = ColabProvider(
            env={"COLAB_GPU": "Tesla T4"},
            content_path="/path/that/does/not/exist",
            torch_module=SimpleNamespace(cuda=FakeCuda()),
            nvidia_smi_path=None,
        )
        info = provider.inspect_runtime()
        self.assertTrue(info["runtime_detected"])
        self.assertEqual(info["gpu"]["torch"]["devices"], [{"index": 0, "name": "Mock GPU"}])
        self.assertEqual(info["gpu"]["torch"]["device_count"], 1)
        self.assertFalse(info["gpu"]["nvidia_smi"]["available"])

    def test_missing_torch_and_nvidia_smi_are_reported_safely(self):
        provider = ColabProvider(env={}, content_path="/missing", torch_module=None, nvidia_smi_path=None)
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(gpu["torch"], {
            "available": False,
            "cuda_available": None,
            "device_count": None,
            "devices": [],
        })
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})

    @patch("providers.colab.subprocess.run")
    def test_nvidia_smi_output_is_parsed_without_shell(self, run):
        run.return_value = SimpleNamespace(returncode=0, stdout="Mock GPU, 16000, 12000\n")
        provider = ColabProvider(env={}, content_path="/missing", torch_module=None, nvidia_smi_path="/mock/nvidia-smi")
        result = provider.inspect_runtime()["gpu"]["nvidia_smi"]
        self.assertTrue(result["query_succeeded"])
        self.assertEqual(result["devices"], [{
            "name": "Mock GPU",
            "memory_total_mib": "16000",
            "memory_free_mib": "12000",
        }])
        args, kwargs = run.call_args
        self.assertEqual(args[0][0], "/mock/nvidia-smi")
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["timeout"], 3)

    def test_drive_storage_requires_mountpoint_and_mydrive(self):
        with tempfile.TemporaryDirectory() as tmp:
            content = Path(tmp) / "content"
            mount = content / "drive"
            my_drive = mount / "MyDrive"
            my_drive.mkdir(parents=True)
            provider = ColabProvider(
                env={"COLAB_RELEASE_TAG": "release"},
                content_path=content,
                drive_mount_path=mount,
                torch_module=None,
                nvidia_smi_path=None,
                drive_mount_checker=lambda path: False,
            )
            self.assertEqual(provider.get_storage_path(), str(content / "minicoder_output"))
            provider._drive_mount_checker = lambda path: True
            self.assertEqual(provider.get_storage_path(), str(my_drive / "minicoder_output"))
            self.assertTrue(provider.inspect_runtime()["drive_mounted"])

    def test_setup_is_inspection_only_and_reports_external_access_unsupported(self):
        with tempfile.TemporaryDirectory() as tmp:
            provider = ColabProvider(env={}, content_path=tmp, torch_module=None, nvidia_smi_path=None)
            info = provider.setup_environment()
            self.assertFalse(info["capabilities"]["submit_cloud_job"])
            self.assertFalse(info["capabilities"]["access_external_colab_session"])
            self.assertFalse(info["capabilities"]["execute_worker_command"])
            self.assertEqual(provider.get_storage_path(), str(Path(tmp) / "minicoder_output"))

    def test_worker_command_is_local_single_node_only_and_not_executed(self):
        with tempfile.TemporaryDirectory() as tmp:
            provider = ColabProvider(env={"COLAB_RELEASE_TAG": "release"}, content_path=tmp, torch_module=None, nvidia_smi_path=None)
            with patch("providers.colab.shutil.which", return_value="/mock/torchrun"):
                command = provider.run_worker_command(0, 1, "127.0.0.1", 12345)
                self.assertIn("--nnodes=1", command)
                self.assertIn("--master_port=12345", command)
                with self.assertRaises(NotImplementedError):
                    provider.run_worker_command(0, 2, "127.0.0.1", 12345)
            with self.assertRaises(NotImplementedError):
                ColabProvider(env={}, content_path=Path(tmp) / "absent", torch_module=None).run_worker_command(
                    0, 1, "127.0.0.1", 12345
                )

    def test_missing_torchrun_and_invalid_port_are_not_reported_as_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            provider = ColabProvider(env={"COLAB_GPU": "GPU"}, content_path=tmp, torch_module=None, nvidia_smi_path=None)
            with patch("providers.colab.shutil.which", return_value=None):
                with self.assertRaises(NotImplementedError):
                    provider.run_worker_command(0, 1, "localhost", 12345)
            with patch("providers.colab.shutil.which", return_value="/mock/torchrun"):
                with self.assertRaises(ValueError):
                    provider.run_worker_command(0, 1, "localhost", 70000)


if __name__ == "__main__":
    unittest.main()
