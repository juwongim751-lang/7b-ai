"""Offline tests for the local-only Hugging Face Spaces / ZeroGPU adapter."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from providers.base import BaseProvider
from providers.huggingface_zerogpu import HuggingFaceZeroGPUProvider


class FakeCuda:
    def is_available(self):
        return True

    def device_count(self):
        return 1

    def get_device_name(self, index):
        return "Mock ZeroGPU"


class TestHuggingFaceZeroGPUProvider(unittest.TestCase):
    def test_implements_base_contract_and_detects_only_injected_space_markers(self):
        provider = HuggingFaceZeroGPUProvider(
            env={"SPACE_ID": "org/demo", "OTHER": "ignored"},
            torch_module=None,
            nvidia_smi_path=None,
        )
        self.assertIsInstance(provider, BaseProvider)
        self.assertEqual(
            provider.detect_runtime(),
            {"detected": True, "indicators": {"space_id": True, "space_host": False}},
        )
        self.assertEqual(
            HuggingFaceZeroGPUProvider(env={"SPACE_HOST": "demo.hf.space"}).detect_runtime(),
            {"detected": True, "indicators": {"space_id": False, "space_host": True}},
        )
        self.assertFalse(HuggingFaceZeroGPUProvider(env={"SPACE_ID": "  ", "SPACE_HOST": ""}).detect_runtime()["detected"])
        self.assertFalse(HuggingFaceZeroGPUProvider(env={"HF_HOME": "/cache"}).detect_runtime()["detected"])

    def test_local_gpu_does_not_claim_zero_gpu_allocation_without_active_context(self):
        provider = HuggingFaceZeroGPUProvider(
            env={"SPACE_ID": "org/demo"},
            torch_module=SimpleNamespace(cuda=FakeCuda()),
            nvidia_smi_path=None,
        )
        gpu = provider.inspect_runtime()["gpu"]
        self.assertTrue(gpu["local_gpu_observed"])
        self.assertFalse(gpu["zerogpu_execution_context_active"])
        self.assertFalse(gpu["zerogpu_allocation_observed"])

    def test_context_flag_and_local_gpu_are_both_required_to_report_allocation(self):
        provider = HuggingFaceZeroGPUProvider(
            env={"SPACE_ID": "org/demo"},
            torch_module=SimpleNamespace(cuda=FakeCuda()),
            nvidia_smi_path=None,
            zerogpu_context_active=True,
        )
        gpu = provider.inspect_runtime()["gpu"]
        self.assertTrue(gpu["zerogpu_execution_context_active"])
        self.assertTrue(gpu["local_gpu_observed"])
        self.assertTrue(gpu["zerogpu_allocation_observed"])

        outside_space = HuggingFaceZeroGPUProvider(
            env={},
            torch_module=SimpleNamespace(cuda=FakeCuda()),
            nvidia_smi_path=None,
            zerogpu_context_active=True,
        ).inspect_runtime()["gpu"]
        self.assertFalse(outside_space["zerogpu_execution_context_active"])
        self.assertFalse(outside_space["zerogpu_allocation_observed"])

    def test_missing_torch_and_nvidia_smi_are_reported_safely(self):
        provider = HuggingFaceZeroGPUProvider(env={}, torch_module=None, nvidia_smi_path=None)
        gpu = provider.inspect_runtime()["gpu"]
        self.assertEqual(
            gpu["torch"],
            {"available": False, "cuda_available": None, "device_count": None, "devices": []},
        )
        self.assertEqual(gpu["nvidia_smi"], {"available": False, "devices": []})
        self.assertFalse(gpu["local_gpu_observed"])
        self.assertFalse(gpu["zerogpu_allocation_observed"])

    @patch("providers.huggingface_zerogpu.subprocess.run")
    def test_nvidia_smi_is_invoked_without_shell_and_parsed(self, run):
        run.return_value = SimpleNamespace(returncode=0, stdout="Mock GPU, 16000, 12000\n")
        provider = HuggingFaceZeroGPUProvider(env={}, torch_module=None, nvidia_smi_path="/mock/nvidia-smi")
        report = provider.inspect_runtime()
        self.assertEqual(
            report["gpu"]["nvidia_smi"]["devices"],
            [{"name": "Mock GPU", "memory_total_mib": "16000", "memory_free_mib": "12000"}],
        )
        self.assertTrue(report["gpu"]["local_gpu_observed"])
        self.assertFalse(report["gpu"]["zerogpu_allocation_observed"])
        args, kwargs = run.call_args
        self.assertEqual(args[0][0], "/mock/nvidia-smi")
        self.assertNotIn("shell", kwargs)
        self.assertEqual(kwargs["timeout"], 3)

    def test_setup_reports_demo_scope_and_only_ephemeral_storage(self):
        with tempfile.TemporaryDirectory() as tmp:
            working = Path(tmp) / "work"
            working.mkdir()
            provider = HuggingFaceZeroGPUProvider(
                env={"SPACE_ID": "org/demo"},
                working_path=working,
                torch_module=None,
                nvidia_smi_path=None,
            )
            report = provider.setup_environment()
            self.assertEqual(report["workload_classification"], "inference_demo_short_evaluation")
            self.assertFalse(report["long_pretraining_supported"])
            self.assertEqual(report["paths"]["checkpoint_storage"]["path"], str(working / "minicoder_output"))
            self.assertFalse(report["paths"]["checkpoint_storage"]["exists"])
            self.assertFalse(report["paths"]["checkpoint_storage"]["persistent"])
            self.assertTrue(report["capabilities"]["write_local_working_directory"])
            for capability in (
                "persistent_storage_verified",
                "generate_local_worker_command",
                "execute_worker_command",
                "submit_cloud_job",
                "access_external_huggingface_space",
                "long_pretraining",
            ):
                self.assertFalse(report["capabilities"][capability])
            self.assertFalse((working / "minicoder_output").exists())
            self.assertEqual(provider.get_storage_path(), str(working / "minicoder_output"))

    def test_worker_command_is_explicitly_unsupported(self):
        provider = HuggingFaceZeroGPUProvider(env={"SPACE_ID": "org/demo"}, torch_module=None, nvidia_smi_path=None)
        with self.assertRaises(NotImplementedError):
            provider.run_worker_command(0, 1, "127.0.0.1", 12345)

    def test_broken_torch_cuda_inspection_is_nonfatal(self):
        provider = HuggingFaceZeroGPUProvider(
            env={},
            torch_module=SimpleNamespace(cuda=SimpleNamespace(is_available=lambda: (_ for _ in ()).throw(RuntimeError()))),
            nvidia_smi_path=None,
        )
        torch_info = provider.inspect_runtime()["gpu"]["torch"]
        self.assertIsNone(torch_info["cuda_available"])
        self.assertIsNone(torch_info["device_count"])
        self.assertEqual(torch_info["devices"], [])
        self.assertEqual(torch_info["inspection_error"], "torch_cuda_inspection_failed")


if __name__ == "__main__":
    unittest.main()
