"""Optional Modal runner. Nothing is submitted unless an explicit cost approval flag is passed."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

try:
    import modal
except ImportError:  # keep local imports optional
    modal = None


if modal is not None:
    project_root = Path(__file__).resolve().parent
    app = modal.App("minicoder-tiny-training")
    image = (modal.Image.debian_slim(python_version="3.11")
             .pip_install("torch>=2.2", "PyYAML>=6.0", "numpy>=1.24", "tokenizers>=0.15")
             .add_local_dir(str(project_root / "model"), remote_path="/root/MiniCoder/model", copy=True)
             .add_local_dir(str(project_root / "training"), remote_path="/root/MiniCoder/training", copy=True)
             .add_local_dir(str(project_root / "dataset"), remote_path="/root/MiniCoder/dataset", copy=True)
             .add_local_dir(str(project_root / "providers"), remote_path="/root/MiniCoder/providers", copy=True)
             .add_local_file(str(project_root / "config" / "model_tiny_10m.yaml"),
                             remote_path="/root/MiniCoder/config/model_tiny_10m.yaml"))
    try:
        # Must be provisioned by the user. No create_if_missing side effect.
        checkpoint_volume = modal.Volume.from_name("minicoder-checkpoints", create_if_missing=False)
    except Exception:
        checkpoint_volume = None

    @app.function(image=image, gpu="T4", timeout=3600,
                  volumes={"/checkpoints": checkpoint_volume} if checkpoint_volume else {})
    def train_tiny(max_steps: int = 8, max_budget_usd: float = 0.0,
                   gpu_cost_rate_usd_per_hour: float = 0.0):
        if checkpoint_volume is None:
            raise RuntimeError("Create the persistent Modal Volume 'minicoder-checkpoints' yourself before running.")
        data_dir = "/checkpoints/data"
        if not os.path.isfile(os.path.join(data_dir, "train.bin")):
            raise FileNotFoundError("Upload a prepared dataset to the Volume at /checkpoints/data first.")
        cmd = ["python", "-m", "training.trainer", "--config", "config/model_tiny_10m.yaml",
               "--data-dir", data_dir, "--run-dir", "/checkpoints/runs/minicoder_tiny_10m",
               "--max-steps", str(max_steps), "--gpu-cost-rate-usd-per-hour", str(gpu_cost_rate_usd_per_hour),
               "--max-budget-usd", str(max_budget_usd), "--confirm-potential-cost"]
        subprocess.run(cmd, cwd="/root/MiniCoder", check=True)
        checkpoint_volume.commit()
        return {"status": "finished", "run_dir": "/checkpoints/runs/minicoder_tiny_10m"}

    @app.local_entrypoint()
    def main(max_steps: int = 8, max_budget_usd: float = 0.0,
             gpu_cost_rate_usd_per_hour: float = 0.0,
             confirm_potential_cost: bool = False):
        if not confirm_potential_cost:
            raise RuntimeError("No job submitted. Review current Modal pricing and account requirements, choose --max-budget-usd, then pass --confirm-potential-cost explicitly.")
        if max_steps < 1 or max_steps > 1000:
            raise ValueError("max_steps must be in [1, 1000]")
        if max_budget_usd <= 0 or gpu_cost_rate_usd_per_hour <= 0:
            raise ValueError("supply a positive, currently reviewed gpu_cost_rate_usd_per_hour and max_budget_usd; the guard is not a provider billing cap")
        return train_tiny.remote(max_steps=max_steps, max_budget_usd=max_budget_usd,
                                 gpu_cost_rate_usd_per_hour=gpu_cost_rate_usd_per_hour)
else:
    app = None

    def main(*args, **kwargs):
        raise RuntimeError("Install the optional Modal SDK in your own Modal environment; no remote work was started.")


if __name__ == "__main__":
    main()
